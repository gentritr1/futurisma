# FUTURISMA — TOTEM handoff

**Status: Phase 1 production vehicle, locked.** Approved shape corrections are final. Kairo
Dynamics and Totem Syndicate remain working names.

Open **`futurisma-handoff.html`** to generate and download every artifact. The models are
authored procedurally, so that page *is* the build: it bakes vertex colours, merges the runtime
model, exports the GLBs, and validates the exported bytes in front of you.

## Deliverables

| Artifact | Where |
| --- | --- |
| Editable source | `totem.js`, `kit-lib.js`, `handoff.js`, `kit-props.js` |
| Master GLB | `futurisma-handoff.html` → Deliverables → `totem_master.glb` |
| Runtime GLB | same → `totem_runtime.glb` |
| Asset-kit GLB | same → `futurisma_asset_kit.glb` |
| Livery atlases, 1024² | same → `totem_decals_1024_{works,privateer,nightform}.png` |
| Emissive sheet, 512² | same → `totem_emissive_512.png` |
| Logos, vector | `assets/kairo-dynamics.svg`, `assets/totem-syndicate.svg` |
| Manifest | `MANIFEST.json` (and a machine copy from the page) |
| Licensing note | this file, section *Origin and licensing* |

## Coordinate setup

- 1 unit = 1 metre. No scene scale, no node scale in either GLB.
- +Y up, nose faces **−Z**, +X starboard, +Z aft. Right-handed, glTF standard.
- Origin at the **approximate centre of mass** — volume-weighted centroid of solid geometry,
  decals and empties excluded.

| Measure | Value |
| --- | --- |
| Length | 6.60 m |
| Width | 3.40 m |
| Height | 2.26 m |
| Origin to skid pad | 0.89 m |
| Resting ride height (keel to ground) | 0.18 m |
| Hover height | 0.45 m cruise · 0.60 m boost · 0.28 m minimum before scrape |
| Keel plane, local Y | −0.712 |

The craft floats above its own origin at rest. That is deliberate: it rotates around the point it
should rotate around, which is why dimensions are quoted against bounds rather than against y = 0.

## Master vs runtime

| | Master | Runtime |
| --- | --- | --- |
| Draw calls | 152 + proxy | **17 drawn** + invisible proxy |
| Materials | 25 | **4** |
| Triangles | 6,186 | 6,186 |
| Nodes | 199 | 53 |
| Bounds | 3.400 × 2.256 × 6.602 m | 3.400 × 2.256 × 6.602 m |

Triangle count and bounds are identical — the merge preserves the silhouette exactly. Statics
collapse to `body_static` and `emissive_static`; everything that animates stays its own node.

Runtime materials: `TOTEM_body` (livery atlas + vertex colours + alphaTest, carries hull,
mechanisms, movers and all 18 decals), `TOTEM_emissive`, `TOTEM_glass`, and the invisible
`TOTEM_collision`.

## Vertex colours

`COLOR_0` on every primitive, as a shading multiplier around 1.0 — never the base colour. Observed
range 0.597 → 1.134. Underside darkening −26% on down-facing normals, top-edge lift +13%, a
0.86 → 1.00 keel-to-deck gradient, ±4.5% per-panel variation hashed from each part name, and heat
staining within 1.25 m of the nozzles with soot aft of z = 2.2.

Base colour comes from the material in the master and from an atlas paint chip in the runtime
model, so a livery swap cannot disturb the shading. Use the page's **Bake only** view to inspect
the channel on its own after any geometry change.

## Movable nodes

13 nodes, each with its origin on the hinge line. Rotate or translate the node — no skinning, no
morph targets. Full table with pivots, axes and ranges in `MANIFEST.json`.

`canopy_pivot` · `airbrake_L/R_pivot` · `steering_fin_L/R_pivot` · `elevon_L/R_pivot` ·
`engine_flap_L/R_0/1_pivot` · `stabiliser_ring_pivot` (roll) · `skids_pivot` (translate −0.22 m)

Ranges in the manifest are design intent, not clamps baked into the file.

## Attachment nodes

20 empties, bound by prefix: `FX_` particles, `LIGHT_` lights, `CAMERA_` camera anchors. Positions
in `MANIFEST.json`.

Two notes for engineering. `FX_boost_center` sits at the hoop centre — draw the merged plume there
so it visibly passes through the ring, which is the point of the silhouette. The four `FX_dust_*`
anchors double as the hover raycast points; if physics wants them elsewhere, split the dust
emitters off rather than moving these.

## Collision

`collision_proxy` — a compound of six boxes, 72 triangles, `visible: false`, exported but never
drawn. Parts: hull core, nose blade, two aft shoulders, two booms. **The stabiliser ring is
excluded on purpose** — it must never block the player.

## Liveries

One geometry, one UV set, one vertex-colour bake, three atlases.

| Livery | Number | Role |
| --- | --- | --- |
| Works | 07 | default hero livery |
| Privateer | 13 | alternate |
| Night form | 24 | unlock / high-speed variant |

The eight paint chips in the atlas bottom strip (region 8, 900, 896 × 96 px) are the entire body
palette. A new team costs one PNG and no build step.

## Validation

All three GLBs **PASS**. Checks run against the exported buffers, not the renderer: header magic
and version, primitive count, `NORMAL` and `TEXCOORD_0` on every primitive, embedded image count
against texture references, node scale drift, alpha modes (`TOTEM_body` MASK, `TOTEM_glass` BLEND),
and world-space bounds recomputed through the node hierarchy to confirm metre scale survived
export. No missing textures, no absent normals, no scale drift, no unexpected transparency.

Worth a second pass in your own viewer before it reaches the engine — this validates the file, not
your renderer's interpretation of it.

## Origin and licensing

- **Geometry** — original, authored procedurally for this project. No purchased, scanned or
  kitbashed base meshes.
- **Textures** — original. Both sheets are drawn programmatically to canvas in `kit-lib.js` and
  `handoff.js`. No photographic source, no stock texture, no AI-generated imagery.
- **Saira** — SIL Open Font License 1.1, Héctor Gatti / Omnibus-Type. Race number, team mark,
  display type.
- **JetBrains Mono** — SIL Open Font License 1.1, JetBrains s.r.o. Stencils, serials, technical
  labels.
- Both fonts are rasterised into the atlas PNGs. The OFL permits this; it requires only that the
  font files themselves not be sold standalone. Ship both `OFL.txt` files with the game's
  third-party notices.
- **three.js 0.184** — MIT. Tooling and viewer only; no runtime dependency in the exported assets.
- **Names** — Kairo Dynamics and Totem Syndicate are working names, not cleared marks. Run a
  trademark search before any public build.

## Package — TOTEM_Phase1_v1.0.zip

Frozen from the validated build. The three GLBs in `models/` are the **exact buffers that produced
the PASS in `VALIDATION.json`** — the package is assembled from the in-memory export, not a
re-export, so the bytes cannot drift. Verified on write: 30 entries, central directory consistent,
every CRC-32 checked.

The table below is written from the live export buffers at pack time, so it always describes the
files in this archive rather than a figure typed by hand.

<!-- BYTES:BEGIN -->
| File | Bytes |
| --- | --- |
| models/totem_master.glb | 669,296 |
| models/totem_runtime.glb | 950,428 |
| models/futurisma_asset_kit.glb | 408,736 |
<!-- BYTES:END -->

```
TOTEM_Phase1_v1.0/
  HANDOFF.md                              this document
  MANIFEST.json                           materials, movers, attachments, dimensions, textures
  VALIDATION.json                         full validation report for all three GLBs
  models/  totem_master.glb               full detail, 6,186 tris, every part named
           totem_runtime.glb              17 drawn calls, 4 materials
           futurisma_asset_kit.glb        ten props, 3,052 tris
  textures/ totem_decals_1024_works.png       default hero livery, number 07
            totem_decals_1024_privateer.png   alternate, number 13
            totem_decals_1024_nightform.png   unlock variant, number 24
            totem_decals_1024_base.png        decal cells only, no paint chips
            totem_emissive_512.png            shared with the asset kit
  logos/   kairo-dynamics.svg              manufacturer emblem, vector
           totem-syndicate.svg             race-team mark, vector
  preview/ 01_master_three_quarter.png     1600 × 1000 identification renders
           02_master_rear.png
           03_master_top.png
           04_runtime_three_quarter.png
           05_collision_proxy.png
           06_asset_kit.png
  source/  totem.js kit-lib.js kit-props.js handoff.js jets.js zip.js
           three-d-stage.js + the four HTML sheets
```

`source/futurisma-handoff.html` runs from this folder as delivered — it resolves `HANDOFF.md`,
`MANIFEST.json` and the logos one level up (and in `logos/`) as well as beside itself, so nothing
needs rearranging to rebuild.

`source/` is a complete snapshot, not a link — the geometry is authored procedurally, so those
files plus `futurisma-handoff.html` regenerate every artifact in the package from scratch.

## Open items

1. Master GLB carries 12 separate decal materials with per-cell texture transforms. Harmless in
   the master, already collapsed in the runtime model — but if you want the master lighter for DCC
   work, say so and the decals can share one material there too.
2. Runtime GLB geometry is non-indexed after the merge. It draws identically; indexing it would cut
   roughly a third off the file size if download budget becomes an issue.
3. No LOD1/LOD2 in this package. Specified on the production sheet (4k at 60 m, 1.2k at 140 m) and
   ready to generate from the same source when you want them.
4. **Queued for before full map production:** a runtime-optimised asset-kit export — shared
   materials across all ten props and an instancing-friendly per-prop structure (one mesh per prop
   type, transforms on the instances, no baked-in world placement). The current kit is 19 materials
   and 128 draw calls, which is accepted for the neutral prototype course but will not hold up once
   props are placed in the hundreds.
