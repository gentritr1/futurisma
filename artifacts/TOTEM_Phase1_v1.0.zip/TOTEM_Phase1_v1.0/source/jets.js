import * as THREE from 'three';

/* ── shared material palette ────────────────────────────────────────── */
export function palette() {
  const mk = (name, color, o = {}) => {
    const m = new THREE.MeshStandardMaterial({ color, roughness: 0.55, metalness: 0.3, ...o });
    m.name = name; return m;
  };
  return {
    carbon: mk('carbon_shell', 0x212830, { roughness: 0.62, metalness: 0.22 }),
    petrol: mk('petrol_blue', 0x164657, { roughness: 0.48, metalness: 0.36 }),
    gun:    mk('gunmetal',    0x707a82, { roughness: 0.40, metalness: 0.38 }),
    grey:   mk('faded_grey',  0xa2a8aa, { roughness: 0.72, metalness: 0.14 }),
    dark:   mk('shadow_black',0x0e1114, { roughness: 0.82, metalness: 0.08 }),
    acid:   mk('acid_paint',  0xc4f230, { roughness: 0.52, metalness: 0.10 }),
    warn:   mk('warning_orange', 0xf2641b, { roughness: 0.60, metalness: 0.10 }),
    cyanL:  mk('emissive_cyan', 0x0c2c34, { emissive: 0x49e2ff, emissiveIntensity: 1.7, roughness: 0.4, metalness: 0 }),
    acidL:  mk('emissive_acid', 0x1d2609, { emissive: 0xc8ff2e, emissiveIntensity: 1.5, roughness: 0.4, metalness: 0 }),
    warnL:  mk('emissive_warn', 0x2a1004, { emissive: 0xff5a12, emissiveIntensity: 1.4, roughness: 0.4, metalness: 0 }),
    glass:  mk('canopy_glass', 0x102e37, { roughness: 0.14, metalness: 0.2, transparent: true, opacity: 0.62 }),
  };
}

/* ── geometry helpers ───────────────────────────────────────────────────
   Plan shapes are written as [x, forward] half-outlines from the nose
   down the right side to the tail centreline; symShape mirrors them.   */

function symShape(half) {
  const s = new THREE.Shape();
  s.moveTo(half[0][0], half[0][1]);
  for (let i = 1; i < half.length; i++) s.lineTo(half[i][0], half[i][1]);
  for (let i = half.length - 2; i >= 0; i--) s.lineTo(-half[i][0], half[i][1]);
  s.closePath();
  return s;
}

// flat horizontal plate: thickness in Y, +forward → −Z
function plate(name, mat, half, thick, { y = 0, bevel = 0.025 } = {}) {
  const g = new THREE.ExtrudeGeometry(symShape(half), {
    depth: thick, steps: 1,
    bevelEnabled: bevel > 0, bevelSize: bevel, bevelThickness: bevel, bevelSegments: 1,
  });
  const m = new THREE.Mesh(g, mat);
  m.name = name;
  m.rotation.x = -Math.PI / 2;
  m.position.y = y;
  return m;
}

// vertical blade (fin / pylon / strut). pts are [forward, up]; thickness in X.
function blade(name, mat, pts, thick, { bevel = 0.02 } = {}) {
  const s = new THREE.Shape();
  s.moveTo(pts[0][0], pts[0][1]);
  for (let i = 1; i < pts.length; i++) s.lineTo(pts[i][0], pts[i][1]);
  s.closePath();
  const g = new THREE.ExtrudeGeometry(s, {
    depth: thick, steps: 1,
    bevelEnabled: bevel > 0, bevelSize: bevel, bevelThickness: bevel, bevelSegments: 1,
  });
  const m = new THREE.Mesh(g, mat);
  m.name = name;
  m.rotation.y = Math.PI / 2;     // shape +x → world −Z (forward)
  m.position.x = -thick / 2;
  const pivot = new THREE.Group();
  pivot.name = name + '_pivot';
  pivot.add(m);
  return pivot;
}

function finalize(g) {
  const b = new THREE.Box3().setFromObject(g);
  const c = b.getCenter(new THREE.Vector3());
  g.children.forEach(ch => { ch.position.x -= c.x; ch.position.y -= b.min.y; ch.position.z -= c.z; });
  return g;
}

function box(name, mat, w, h, d, pos, rot) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
  m.name = name;
  m.position.set(...pos);
  if (rot) m.rotation.set(...rot);
  return m;
}

function tube(name, mat, r, len, pos, seg = 12, open = true) {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, len, seg, 1, open), mat);
  m.name = name;
  m.rotation.x = Math.PI / 2;
  m.position.set(...pos);
  return m;
}

function glowDisc(name, mat, r, pos, seg = 12) {
  const m = new THREE.Mesh(new THREE.CircleGeometry(r, seg), mat);
  m.name = name;
  m.position.set(...pos);
  return m;
}

// twin-mirrored helper: build once per side with a sign
function mirror(group, fn) { [-1, 1].forEach(s => group.add(fn(s, s < 0 ? 'L' : 'R'))); }

/* ── engine nacelle: intake lip, faceted barrel, exhaust bell + glow ─── */
function nacelle(name, P, { r = 0.34, len = 2.2, seg = 12 } = {}) {
  const g = new THREE.Group();
  g.name = name;
  g.add(tube(name + '_barrel', P.carbon, r, len, [0, 0, 0], seg));
  g.add(tube(name + '_liner', P.dark, r * 0.86, len * 0.98, [0, 0, 0], seg));
  const lip = new THREE.Mesh(new THREE.TorusGeometry(r * 0.94, r * 0.14, 6, seg), P.gun);
  lip.name = name + '_intake_lip';
  lip.position.z = -len / 2;
  g.add(lip);
  const bell = new THREE.Mesh(new THREE.CylinderGeometry(r * 1.08, r * 0.9, len * 0.22, seg, 1, true), P.gun);
  bell.name = name + '_exhaust_bell';
  bell.rotation.x = Math.PI / 2;
  bell.position.z = len / 2 - 0.02;
  g.add(bell);
  g.add(glowDisc(name + '_exhaust_glow', P.cyanL, r * 0.82, [0, 0, len / 2 + 0.06], seg));
  // maintenance panel + flap (movable)
  const flap = blade(name + '_flap', P.gun, [[0, -r * 0.9], [0.42, -r * 1.02], [0.42, r * 0.1], [0, r * 0.1]], 0.05);
  flap.position.set(0, 0, len / 2 - 0.45);
  flap.rotation.x = 0.18;
  g.add(flap);
  return g;
}

function skid(name, P, pos, len = 0.7) {
  const g = new THREE.Group();
  g.name = name + '_pivot';
  g.position.set(...pos);
  g.add(box(name + '_strut', P.gun, 0.07, 0.26, 0.09, [0, 0.13, 0]));
  g.add(box(name + '_pad', P.dark, 0.16, 0.07, len, [0, 0.035, 0]));
  return g;
}

/* ══ A — VESPERTINE : split-tail delta ══════════════════════════════ */
export function buildVespertine() {
  const P = palette(), g = new THREE.Group();
  g.name = 'FTR_A_vespertine';

  g.add(plate('underfloor', P.dark,
    [[0, 2.80], [0.24, 2.20], [0.36, 1.25], [0.90, 0.45], [1.76, -0.85], [1.70, -1.28], [0.62, -1.26], [0, -1.33]],
    0.16, { y: 0.16 }));
  g.add(plate('main_delta', P.carbon,
    [[0, 3.18], [0.27, 2.48], [0.41, 1.35], [1.00, 0.50], [2.04, -0.95], [1.98, -1.44], [0.76, -1.36], [0.66, -1.70], [0, -1.76]],
    0.26, { y: 0.32 }));
  g.add(plate('dorsal_spine', P.petrol,
    [[0, 2.88], [0.26, 2.05], [0.37, 0.60], [0.44, -1.00], [0.36, -1.62], [0, -1.66]],
    0.40, { y: 0.58 }));
  g.add(box('spine_light_bar', P.acidL, 0.10, 0.05, 3.2, [0, 1.00, 0.05]));
  g.add(plate('nose_shroud', P.gun,
    [[0, 3.26], [0.19, 2.60], [0.25, 1.90], [0, 1.86]], 0.28, { y: 0.44 }));

  const canopy = new THREE.Mesh(new THREE.SphereGeometry(0.4, 10, 6), P.glass);
  canopy.name = 'canopy';
  canopy.scale.set(0.72, 0.62, 1.85);
  canopy.position.set(0, 0.94, -1.45);
  const canopyPivot = new THREE.Group();
  canopyPivot.name = 'canopy_pivot';
  canopyPivot.add(canopy);
  g.add(canopyPivot);
  g.add(box('cockpit_collar', P.dark, 0.56, 0.10, 1.5, [0, 0.90, -1.45]));

  mirror(g, s => {
    const n = nacelle('engine_' + (s < 0 ? 'L' : 'R'), P, { r: 0.36, len: 2.35 });
    n.position.set(s * 1.10, 0.50, 0.30);
    return n;
  });
  mirror(g, (s, k) => {
    const f = blade('vtail_' + k, P.carbon, [[-0.15, 0], [0.95, 0.02], [0.66, 0.98], [-0.08, 0.66]], 0.07);
    f.position.set(s * 0.42, 0.95, 0.85);
    f.rotation.z = s * 0.52;
    return f;
  });
  mirror(g, (s, k) => {
    const b = box('airbrake_' + k, P.acid, 0.52, 0.05, 0.34, [s * 1.02, 0.63, 0.92], [-0.52, 0, 0]);
    return b;
  });
  mirror(g, (s, k) => {
    const c = blade('canard_' + k, P.gun, [[0, 0], [0.5, 0.06], [0.42, 0.34], [0, 0.30]], 0.05);
    c.position.set(s * 0.36, 0.72, -2.20);
    c.rotation.z = -s * 0.28;
    return c;
  });
  mirror(g, (s, k) => box('wingtip_lamp_' + k, s < 0 ? P.warnL : P.acidL, 0.10, 0.07, 0.26, [s * 1.90, 0.44, 0.88]));
  mirror(g, (s, k) => skid('skid_' + k, P, [s * 1.10, 0, 0.55], 0.8));
  g.add(skid('skid_nose', P, [0, 0, -1.7], 0.55));
  return finalize(g);
}

/* ══ B — TOTEM : blade fuselage + exposed stabiliser ring ═══════════ */
export function buildTotem() {
  const P = palette(), g = new THREE.Group();
  g.name = 'FTR_B_totem';

  g.add(plate('keel', P.dark,
    [[0, 2.85], [0.20, 2.2], [0.26, 0.8], [0.34, -1.0], [0.44, -2.1], [0, -2.2]], 0.16, { y: 0.20 }));
  g.add(plate('fuselage_blade', P.carbon,
    [[0, 3.15], [0.24, 2.45], [0.32, 1.00], [0.40, -0.60], [0.56, -1.95], [0.58, -2.45], [0, -2.55]], 0.40, { y: 0.34 }));
  g.add(plate('spine_deck', P.petrol,
    [[0, 2.55], [0.24, 1.70], [0.30, -0.40], [0.26, -1.90], [0, -1.95]], 0.34, { y: 0.72 }));
  g.add(box('spine_light_bar', P.acidL, 0.08, 0.05, 3.3, [0, 1.04, -0.35]));

  const canopy = new THREE.Mesh(new THREE.SphereGeometry(0.36, 10, 6), P.glass);
  canopy.name = 'canopy';
  canopy.scale.set(0.66, 0.66, 2.1);
  canopy.position.set(0, 0.98, -1.65);
  const cp = new THREE.Group(); cp.name = 'canopy_pivot'; cp.add(canopy); g.add(cp);

  // forward outrigger booms + canards
  mirror(g, (s, k) => {
    const grp = new THREE.Group(); grp.name = 'outrigger_' + k;
    grp.add(tube('boom_' + k, P.gun, 0.13, 2.7, [s * 1.30, 0.52, -1.10], 10, false));
    grp.add(box('boom_tip_' + k, P.dark, 0.20, 0.16, 0.4, [s * 1.30, 0.52, -2.55]));
    grp.add(box('boom_lamp_' + k, s < 0 ? P.warnL : P.cyanL, 0.14, 0.10, 0.10, [s * 1.30, 0.52, -2.76]));
    grp.add(box('boom_strut_' + k, P.carbon, 1.30, 0.14, 0.34, [s * 0.68, 0.52, -0.85], [0, s * 0.22, 0]));
    const can = blade('canard_' + k, P.acid, [[0, 0], [0.62, 0.04], [0.44, 0.40], [-0.02, 0.34]], 0.05);
    can.position.set(s * 1.30, 0.60, -2.25);
    can.rotation.z = -s * 0.30;
    grp.add(can);
    return grp;
  });

  // exposed stabiliser ring — the signature
  const ringGrp = new THREE.Group(); ringGrp.name = 'stabiliser_ring';
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.96, 0.085, 6, 22), P.gun);
  ring.name = 'ring_hoop'; ring.position.set(0, 0.78, 2.55);
  ringGrp.add(ring);
  [0, 1, 2, 3].forEach(i => {
    const a = Math.PI / 4 + i * Math.PI / 2;
    const s = box('ring_spar_' + i, P.carbon, 0.10, 0.10, 0.95, [Math.cos(a) * 0.52, 0.78 + Math.sin(a) * 0.52, 2.2]);
    s.lookAt(new THREE.Vector3(Math.cos(a) * 0.96, 0.78 + Math.sin(a) * 0.96, 2.55));
    ringGrp.add(s);
  });
  mirror(ringGrp, (s, k) => box('ring_beacon_' + k, s < 0 ? P.acidL : P.cyanL, 0.14, 0.14, 0.09, [s * 0.96, 0.78, 2.55]));
  g.add(ringGrp);

  mirror(g, (s, k) => {
    const n = nacelle('engine_' + k, P, { r: 0.30, len: 1.9 });
    n.position.set(s * 0.42, 0.78, 1.55);
    return n;
  });
  const fin = blade('dorsal_fin', P.carbon, [[-0.2, 0], [1.05, 0.06], [0.72, 0.92], [-0.12, 0.62]], 0.08);
  fin.position.set(0, 1.02, 1.05);
  g.add(fin);
  mirror(g, (s, k) => {
    const b = box('airbrake_' + k, P.warn, 0.06, 0.46, 0.30, [s * 0.60, 0.72, 1.15], [0, s * 0.55, 0]);
    return b;
  });
  mirror(g, (s, k) => skid('skid_' + k, P, [s * 0.48, 0, 1.6], 0.85));
  g.add(skid('skid_nose', P, [0, 0, -2.05], 0.6));
  return finalize(g);
}

/* ══ C — GRAVER : wide plank + high canted pods ════════════════════ */
export function buildGraver() {
  const P = palette(), g = new THREE.Group();
  g.name = 'FTR_C_graver';

  g.add(plate('plank_floor', P.dark,
    [[0, 2.15], [0.55, 1.90], [0.92, 1.10], [1.42, 0.0], [1.88, -1.15], [1.70, -1.50], [0, -1.55]], 0.14, { y: 0.14 }));
  g.add(plate('plank_deck', P.carbon,
    [[0, 2.42], [0.62, 2.10], [1.02, 1.22], [1.58, 0.0], [2.12, -1.30], [1.92, -1.72], [0, -1.78]], 0.22, { y: 0.28 }));
  g.add(plate('centre_hump', P.petrol,
    [[0, 2.10], [0.42, 1.55], [0.52, 0.20], [0.48, -1.35], [0, -1.42]], 0.44, { y: 0.50 }));
  g.add(box('spine_light_bar', P.acidL, 0.09, 0.05, 2.3, [0, 0.96, 0.10]));
  g.add(plate('chisel_nose', P.gun, [[0, 2.62], [0.34, 2.05], [0.40, 1.55], [0, 1.50]], 0.26, { y: 0.34 }));

  const canopy = new THREE.Mesh(new THREE.SphereGeometry(0.38, 10, 6), P.glass);
  canopy.name = 'canopy'; canopy.scale.set(0.70, 0.60, 1.6);
  canopy.position.set(0, 0.92, -1.25);
  const cp = new THREE.Group(); cp.name = 'canopy_pivot'; cp.add(canopy); g.add(cp);

  mirror(g, (s, k) => {
    const grp = new THREE.Group(); grp.name = 'podset_' + k;
    const pyl = blade('pylon_' + k, P.carbon, [[-0.55, 0], [0.75, 0], [0.55, 0.78], [-0.40, 0.78]], 0.13);
    pyl.position.set(s * 1.30, 0.44, 0.10);
    pyl.rotation.z = -s * 0.30;
    grp.add(pyl);
    const n = nacelle('engine_' + k, P, { r: 0.40, len: 2.05 });
    n.position.set(s * 1.52, 1.16, 0.25);
    n.rotation.z = s * 0.10;
    grp.add(n);
    const cap = blade('pod_fin_' + k, P.acid, [[0.10, 0], [0.85, 0.04], [0.62, 0.52], [0.06, 0.44]], 0.05);
    cap.position.set(s * 1.52, 1.52, 0.35);
    grp.add(cap);
    return grp;
  });

  mirror(g, (s, k) => {
    const c = blade('canard_scythe_' + k, P.gun, [[0, 0], [0.86, 0.10], [0.98, 0.52], [0.22, 0.30]], 0.06);
    c.position.set(s * 0.62, 0.60, -1.95);
    c.rotation.z = -s * 0.42;
    return c;
  });
  mirror(g, (s, k) => {
    const f = blade('stub_fin_' + k, P.carbon, [[-0.05, 0], [0.62, 0.04], [0.44, 0.60], [-0.05, 0.42]], 0.07);
    f.position.set(s * 1.92, 0.50, 1.05);
    f.rotation.z = s * 0.16;
    return f;
  });
  mirror(g, (s, k) => box('airbrake_' + k, P.warn, 0.60, 0.05, 0.30, [s * 1.20, 0.55, 1.22], [-0.6, 0, 0]));
  mirror(g, (s, k) => box('tip_lamp_' + k, s < 0 ? P.warnL : P.cyanL, 0.12, 0.07, 0.22, [s * 1.99, 0.36, 1.18]));
  mirror(g, (s, k) => skid('skid_' + k, P, [s * 1.45, 0, 0.9], 0.8));
  g.add(skid('skid_nose', P, [0, 0, -1.55], 0.55));
  return finalize(g);
}
