import * as THREE from 'three';
import { GLTFExporter } from 'three/addons/exporters/GLTFExporter.js';
import { buildTotem } from './totem.js';
import { decalAtlas, emissiveSheet } from './kit-lib.js';

/* ══ paint chips ══════════════════════════════════════════════════════
   Eight 96² opaque swatches in the atlas's free bottom strip. Runtime
   hull UVs collapse to a chip centre, so one texture carries every body
   colour and a livery is a texture swap on identical geometry.        */

export const CHIPS = ['carbon_shell', 'petrol_panel', 'gunmetal_mech', 'faded_grey',
  'shadow_black', 'acid_paint', 'warning_orange', 'oxide_patch'];

export const LIVERY_CHIPS = {
  works:     ['#212830', '#164657', '#707a82', '#a2a8aa', '#0e1114', '#c4f230', '#f2641b', '#6b4630'],
  privateer: ['#2c3138', '#6b6f6a', '#7a828a', '#cfcabc', '#12161a', '#f2641b', '#f2641b', '#7a4a2c'],
  nightform: ['#14181c', '#122b36', '#5d666d', '#8d9498', '#0a0c0e', '#49e2ff', '#c2461a', '#4b3526'],
};
export const LIVERY_META = {
  works:     { label: 'Works', number: '07', team: 'TOTEM SYNDICATE', role: 'default hero livery' },
  privateer: { label: 'Privateer', number: '13', team: 'ROUTE 13 PRIVATEER', role: 'alternate' },
  nightform: { label: 'Night form', number: '24', team: 'TOTEM NIGHT FORM', role: 'unlock / high-speed variant' },
};

const CHIP = { size: 96, y: 900, x0: 8, step: 112 };
export function chipUV(materialName) {
  const i = CHIPS.indexOf(materialName);
  const k = i < 0 ? 0 : i;
  const cx = CHIP.x0 + k * CHIP.step + CHIP.size / 2;
  const cy = CHIP.y + CHIP.size / 2;
  return [cx / 1024, 1 - cy / 1024];
}

/** Livery atlas: decal cells + the eight paint chips, 1024². */
export function liveryAtlas(livery = 'works') {
  const meta = LIVERY_META[livery];
  const cv = decalAtlas(1024, { number: meta.number, team: meta.team });
  const x = cv.getContext('2d');
  LIVERY_CHIPS[livery].forEach((hex, i) => {
    x.fillStyle = hex;
    x.fillRect(CHIP.x0 + i * CHIP.step, CHIP.y, CHIP.size, CHIP.size);
    x.strokeStyle = 'rgba(0,0,0,.55)'; x.lineWidth = 2;
    x.strokeRect(CHIP.x0 + i * CHIP.step + 1, CHIP.y + 1, CHIP.size - 2, CHIP.size - 2);
  });
  x.fillStyle = '#8b969a';
  x.font = '500 15px "JetBrains Mono", monospace';
  x.fillText('PAINT CHIPS · ' + meta.label.toUpperCase(), CHIP.x0, CHIP.y - 12);
  return cv;
}

/* emissive bands in the 512² sheet */
const EMIS_UV = {
  emissive_cyan: [0.5, 1 - 22 / 512],
  emissive_acid: [0.5, 1 - 86 / 512],
  emissive_warn: [0.25, 1 - 137 / 512],
};

/* ══ vertex colour bake ═══════════════════════════════════════════════
   Multiplier around 1.0 — base colour stays in the material (master) or
   the chip (runtime). Underside darkening, top-edge lift, per-panel
   variation, and heat staining aft of the nozzles.                    */

const HEAT = [new THREE.Vector3(-0.45, 0.74, 2.55), new THREE.Vector3(0.45, 0.74, 2.55)];

function hash01(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
  return ((h >>> 0) % 1000) / 1000;
}

export function paintVertexColours(root, { hullMin = 0, hullMax = 1.9 } = {}) {
  root.updateMatrixWorld(true);
  const wp = new THREE.Vector3(), wn = new THREE.Vector3();
  const nMat = new THREE.Matrix3();
  let painted = 0;
  root.traverse(o => {
    if (!o.isMesh) return;
    const mn = (o.material && o.material.name) || '';
    if (mn.startsWith('marker_')) return;
    const g = o.geometry;
    const pos = g.attributes.position, nor = g.attributes.normal;
    if (!pos) return;
    const decal = mn.startsWith('decal_');
    const emis = mn.startsWith('emissive_');
    const panel = 0.955 + hash01(o.name) * 0.09;
    const col = new Float32Array(pos.count * 3);
    nMat.getNormalMatrix(o.matrixWorld);
    for (let i = 0; i < pos.count; i++) {
      let r = 1, gg = 1, b = 1;
      if (!emis) {
        wp.fromBufferAttribute(pos, i).applyMatrix4(o.matrixWorld);
        const ny = nor ? wn.fromBufferAttribute(nor, i).applyMatrix3(nMat).normalize().y : 0;
        let k = panel;
        if (ny > 0.35) k += 0.13 * (ny - 0.35) / 0.65;          // top edges catch the key light
        if (ny < -0.15) k -= 0.26 * Math.min(1, -ny);            // undersides go dark
        const h = THREE.MathUtils.clamp((wp.y - hullMin) / (hullMax - hullMin), 0, 1);
        k *= 0.86 + 0.14 * h;                                    // ambient gradient, bottom to top
        r = gg = b = k;
        if (!decal) {                                            // heat stain aft of the nozzles
          let heat = 0;
          for (const hp of HEAT) heat = Math.max(heat, 1 - THREE.MathUtils.clamp(wp.distanceTo(hp) / 1.25, 0, 1));
          if (wp.z < 1.1) heat = 0;
          r += heat * 0.13; gg += heat * 0.01; b -= heat * 0.10;
          const soot = wp.z > 2.2 ? THREE.MathUtils.clamp((wp.z - 2.2) / 0.9, 0, 1) * 0.16 : 0;
          r -= soot; gg -= soot; b -= soot * 0.7;
        }
      }
      col[i * 3] = Math.max(0, r); col[i * 3 + 1] = Math.max(0, gg); col[i * 3 + 2] = Math.max(0, b);
    }
    g.setAttribute('color', new THREE.BufferAttribute(col, 3));
    if (o.material) o.material.vertexColors = true;
    painted++;
  });
  return painted;
}

/* ══ geometry merge (no BufferGeometryUtils in the pinned map) ════════ */

function mergeMeshes(meshes, rootMatrixInv, { uvFor } = {}) {
  const pos = [], nor = [], uv = [], col = [];
  const m4 = new THREE.Matrix4();
  for (const m of meshes) {
    const g = (m.geometry.index ? m.geometry.toNonIndexed() : m.geometry.clone());
    m4.multiplyMatrices(rootMatrixInv, m.matrixWorld);
    g.applyMatrix4(m4);
    const p = g.attributes.position, n = g.attributes.normal, c = g.attributes.color, u = g.attributes.uv;
    const fixed = uvFor ? uvFor(m) : null;
    const map = m.material && m.material.map;
    for (let i = 0; i < p.count; i++) {
      pos.push(p.getX(i), p.getY(i), p.getZ(i));
      nor.push(n ? n.getX(i) : 0, n ? n.getY(i) : 1, n ? n.getZ(i) : 0);
      if (fixed) uv.push(fixed[0], fixed[1]);
      else if (u && map) uv.push(map.offset.x + u.getX(i) * map.repeat.x, map.offset.y + u.getY(i) * map.repeat.y);
      else if (u) uv.push(u.getX(i), u.getY(i));
      else uv.push(0, 0);
      col.push(c ? c.getX(i) : 1, c ? c.getY(i) : 1, c ? c.getZ(i) : 1);
    }
    g.dispose();
  }
  const out = new THREE.BufferGeometry();
  out.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  out.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3));
  out.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  out.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
  return out;
}

/* ══ collision proxy ══════════════════════════════════════════════════ */

export function collisionProxy(material, originOffset = [0, 0, 0]) {
  const boxes = [
    ['hull_core', [0, 0.45, 0.35], [0.95, 0.62, 3.1]],
    ['nose_blade', [0, 0.42, -2.35], [0.52, 0.44, 1.9]],
    ['shoulder_left', [-1.0, 0.42, 1.85], [1.15, 0.44, 1.9]],
    ['shoulder_right', [1.0, 0.42, 1.85], [1.15, 0.44, 1.9]],
    ['boom_left', [-1.38, 0.44, -1.75], [0.3, 0.3, 2.7]],
    ['boom_right', [1.38, 0.44, -1.75], [0.3, 0.3, 2.7]],
  ];
  const meshes = boxes.map(([n, p, s]) => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(...s), material);
    m.name = 'COL_' + n;
    m.position.set(p[0] - originOffset[0], p[1] - originOffset[1], p[2] - originOffset[2]);
    m.updateMatrixWorld(true);
    return m;
  });
  const geo = mergeMeshes(meshes, new THREE.Matrix4());
  const proxy = new THREE.Mesh(geo, material);
  proxy.name = 'collision_proxy';
  proxy.visible = false;
  proxy.userData = { collision: true, shape: 'compound_box', parts: boxes.length };
  return proxy;
}

/* ══ runtime build ════════════════════════════════════════════════════ */

function classify(materialName) {
  if (materialName.startsWith('emissive_')) return 'emis';
  if (materialName === 'canopy_smoke') return 'glass';
  if (materialName.startsWith('marker_')) return 'skip';
  return 'body';
}

export function runtimeMaterials(atlasCanvas, emisCanvas) {
  const tex = (cv) => {
    const t = new THREE.CanvasTexture(cv);
    t.colorSpace = THREE.SRGBColorSpace;
    t.anisotropy = 1; t.generateMipmaps = true;
    t.minFilter = THREE.LinearMipmapLinearFilter; t.magFilter = THREE.LinearFilter;
    return t;
  };
  const atlas = tex(atlasCanvas), emis = tex(emisCanvas);
  const body = new THREE.MeshStandardMaterial({
    map: atlas, vertexColors: true, alphaTest: 0.5,
    roughness: 0.62, metalness: 0.25,
  });
  body.name = 'TOTEM_body';
  const emissive = new THREE.MeshStandardMaterial({
    map: emis, emissiveMap: emis, emissive: 0xffffff, emissiveIntensity: 1.6,
    roughness: 0.4, metalness: 0,
  });
  emissive.name = 'TOTEM_emissive';
  const glass = new THREE.MeshStandardMaterial({
    color: 0x102e37, roughness: 0.13, metalness: 0.2, transparent: true, opacity: 0.6,
  });
  glass.name = 'TOTEM_glass';
  const collision = new THREE.MeshStandardMaterial({ color: 0xff00aa, wireframe: true });
  collision.name = 'TOTEM_collision';
  return { body, emissive, glass, collision };
}

/** Optimised runtime model: statics merged per material, every mover kept
 *  as its own named node with its own local pivot. */
export function buildRuntime({ livery = 'works', atlasCanvas, emisCanvas } = {}) {
  const atlas = atlasCanvas || liveryAtlas(livery);
  const emis = emisCanvas || emissiveSheet(512);
  const master = buildTotem({ livery, atlas, origin: 'com' });
  paintVertexColours(master);
  master.updateMatrixWorld(true);
  const M = runtimeMaterials(atlas, emis);
  const rootInv = new THREE.Matrix4().copy(master.matrixWorld).invert();

  const moverOf = (o) => {
    let p = o;
    while (p && p !== master) { if (p.userData && p.userData.mover) return p; p = p.parent; }
    return null;
  };
  const statics = { body: [], emis: [], glass: [] };
  const movers = new Map();
  master.traverse(o => {
    if (!o.isMesh) return;
    const cls = classify((o.material && o.material.name) || '');
    if (cls === 'skip') return;
    const mv = moverOf(o);
    if (mv) {
      if (!movers.has(mv)) movers.set(mv, { body: [], emis: [], glass: [] });
      movers.get(mv)[cls].push(o);
    } else statics[cls].push(o);
  });

  const uvBody = (m) => {
    const n = (m.material && m.material.name) || '';
    return n.startsWith('decal_') ? null : chipUV(n);
  };
  const uvEmis = (m) => EMIS_UV[(m.material && m.material.name) || ''] || [0.5, 0.5];

  const out = new THREE.Group();
  out.name = 'TOTEM_runtime_' + livery;
  const drawCalls = [];
  const add = (parent, geo, mat, name) => {
    const mesh = new THREE.Mesh(geo, mat);
    mesh.name = name;
    parent.add(mesh);
    drawCalls.push(name);
    return mesh;
  };
  if (statics.body.length) add(out, mergeMeshes(statics.body, rootInv, { uvFor: uvBody }), M.body, 'body_static');
  if (statics.emis.length) add(out, mergeMeshes(statics.emis, rootInv, { uvFor: uvEmis }), M.emissive, 'emissive_static');
  if (statics.glass.length) add(out, mergeMeshes(statics.glass, rootInv), M.glass, 'glass_static');

  const moverInfo = [];
  for (const [pivot, buckets] of movers) {
    const node = new THREE.Group();
    node.name = pivot.name;
    node.position.copy(pivot.position);
    node.rotation.copy(pivot.rotation);
    node.userData = { ...pivot.userData };
    // merge relative to the pivot, so local rotation reproduces the hinge
    pivot.updateMatrixWorld(true);
    const inv = new THREE.Matrix4().copy(pivot.matrixWorld).invert();
    if (buckets.body.length) add(node, mergeMeshes(buckets.body, inv, { uvFor: uvBody }), M.body, pivot.name.replace('_pivot', '') + '_body');
    if (buckets.emis.length) add(node, mergeMeshes(buckets.emis, inv, { uvFor: uvEmis }), M.emissive, pivot.name.replace('_pivot', '') + '_emissive');
    if (buckets.glass.length) add(node, mergeMeshes(buckets.glass, inv), M.glass, pivot.name.replace('_pivot', '') + '_glass');
    out.add(node);
    moverInfo.push({
      node: pivot.name,
      position: node.position.toArray().map(v => +v.toFixed(3)),
      ...pivot.userData,
      primitives: (buckets.body.length ? 1 : 0) + (buckets.emis.length ? 1 : 0) + (buckets.glass.length ? 1 : 0),
    });
  }

  // attachment empties, copied off the master
  const att = new THREE.Group(); att.name = 'attachments';
  const attInfo = [];
  const src = master.getObjectByName('attachments');
  if (src) src.children.forEach(o => {
    const e = new THREE.Object3D();
    e.name = o.name;
    e.position.copy(o.position);
    att.add(e);
    attInfo.push({ node: o.name, position: e.position.toArray().map(v => +v.toFixed(3)) });
  });
  out.add(att);
  out.add(collisionProxy(M.collision, master.userData.originOffset));

  return { runtime: out, master, materials: M, drawCalls, moverInfo, attInfo, atlas, emis };
}

/* ══ measurement ══════════════════════════════════════════════════════ */

export function measure(model) {
  const bb = new THREE.Box3().setFromObject(model);
  const sz = bb.getSize(new THREE.Vector3());
  let tris = 0, meshes = 0;
  const mats = new Set();
  model.traverse(o => {
    if (!o.isMesh) return;
    meshes++;
    if (o.material) mats.add(o.material.name);
    const g = o.geometry;
    tris += (g.index ? g.index.count : g.attributes.position.count) / 3;
  });
  return {
    length_m: +sz.z.toFixed(3), width_m: +sz.x.toFixed(3), height_m: +sz.y.toFixed(3),
    min: bb.min.toArray().map(v => +v.toFixed(3)), max: bb.max.toArray().map(v => +v.toFixed(3)),
    triangles: Math.round(tris), meshes, materials: [...mats].sort(),
  };
}

/* ══ GLB export + validation ══════════════════════════════════════════ */

export function exportGLB(object) {
  return new Promise((res, rej) => {
    new GLTFExporter().parse(object, res, rej, { binary: true, onlyVisible: false, embedImages: true });
  });
}

/** Read the exported bytes back and check the things that break in
 *  engines: missing images, absent normals, scale drift, alpha modes. */
export function validateGLB(buffer) {
  const dv = new DataView(buffer);
  const magic = String.fromCharCode(dv.getUint8(0), dv.getUint8(1), dv.getUint8(2), dv.getUint8(3));
  const version = dv.getUint32(4, true);
  const jsonLen = dv.getUint32(12, true);
  const jsonStr = new TextDecoder().decode(new Uint8Array(buffer, 20, jsonLen));
  const gl = JSON.parse(jsonStr);
  const prims = (gl.meshes || []).reduce((n, m) => n + m.primitives.length, 0);
  let tris = 0, noNormal = 0, noColour = 0, noUV = 0;
  for (const m of gl.meshes || []) for (const p of m.primitives) {
    const acc = gl.accessors[p.indices !== undefined ? p.indices : p.attributes.POSITION];
    tris += acc.count / 3;
    if (p.attributes.NORMAL === undefined) noNormal++;
    if (p.attributes.COLOR_0 === undefined) noColour++;
    if (p.attributes.TEXCOORD_0 === undefined) noUV++;
  }
  const nodes = gl.nodes || [];
  const scaled = nodes.filter(n => n.scale && n.scale.some(v => Math.abs(v - 1) > 1e-4)).map(n => n.name);
  const named = nodes.filter(n => n.name).length;
  const missingImage = (gl.textures || []).filter(t => t.source === undefined).length;
  const imagesEmbedded = (gl.images || []).filter(i => i.bufferView !== undefined || (i.uri || '').startsWith('data:')).length;
  // world-space bounds: walk the node hierarchy, transform each primitive's
  // accessor min/max corners — local accessor extents alone are meaningless
  const bb = new THREE.Box3();
  const v = new THREE.Vector3();
  const walk = (idx, parent) => {
    const n = gl.nodes[idx];
    const local = new THREE.Matrix4();
    if (n.matrix) local.fromArray(n.matrix);
    else local.compose(
      new THREE.Vector3().fromArray(n.translation || [0, 0, 0]),
      new THREE.Quaternion().fromArray(n.rotation || [0, 0, 0, 1]),
      new THREE.Vector3().fromArray(n.scale || [1, 1, 1]));
    const m = parent.clone().multiply(local);
    if (n.mesh !== undefined) {
      for (const p of gl.meshes[n.mesh].primitives) {
        const a = gl.accessors[p.attributes.POSITION];
        if (!a || !a.min) continue;
        for (let i = 0; i < 8; i++) {
          v.set(i & 1 ? a.max[0] : a.min[0], i & 2 ? a.max[1] : a.min[1], i & 4 ? a.max[2] : a.min[2]);
          bb.expandByPoint(v.applyMatrix4(m));
        }
      }
    }
    (n.children || []).forEach(c => walk(c, m));
  };
  const sceneNodes = (gl.scenes && gl.scenes[gl.scene || 0].nodes) || [];
  sceneNodes.forEach(i => walk(i, new THREE.Matrix4()));
  const lo = bb.min.toArray(), hi = bb.max.toArray();
  return {
    ok: magic === 'glTF' && version === 2 && noNormal === 0 && missingImage === 0 && scaled.length === 0,
    magic, version, bytes: buffer.byteLength,
    drawCalls: prims, triangles: Math.round(tris),
    materials: (gl.materials || []).map(m => m.name || '(unnamed)'),
    images: (gl.images || []).length, imagesEmbedded, missingImage,
    textures: (gl.textures || []).length,
    alphaModes: (gl.materials || []).map(m => `${m.name || '?'}: ${m.alphaMode || 'OPAQUE'}`),
    doubleSided: (gl.materials || []).filter(m => m.doubleSided).map(m => m.name),
    nodes: nodes.length, namedNodes: named,
    emptyNodes: nodes.filter(n => n.mesh === undefined && !n.children).map(n => n.name).filter(Boolean),
    primitivesMissingNormals: noNormal, primitivesMissingUV: noUV, primitivesMissingColour: noColour,
    nonUniformScaledNodes: scaled,
    boundsMin: lo.map(v => +v.toFixed(3)), boundsMax: hi.map(v => +v.toFixed(3)),
    dimensions_m: hi.map((v, i) => +(v - lo[i]).toFixed(3)),
  };
}

export function download(name, blobOrBuffer, type = 'application/octet-stream') {
  const blob = blobOrBuffer instanceof Blob ? blobOrBuffer : new Blob([blobOrBuffer], { type });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}
