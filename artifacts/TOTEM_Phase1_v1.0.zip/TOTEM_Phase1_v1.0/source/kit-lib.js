import * as THREE from 'three';

/* ══ FUTURISMA shared build library ═══════════════════════════════════
   Forward is −Z, up is +Y. Plan shapes are half-outlines [x, forward]
   from the nose down the right side to the tail centreline.           */

export const HEX = {
  carbon: 0x212830, petrol: 0x164657, gun: 0x707a82, grey: 0xa2a8aa,
  dark: 0x0e1114, acid: 0xc4f230, warn: 0xf2641b, bone: 0xcfcabc,
  rust: 0x6b4630, teamblue: 0x1d5f7a, cyan: 0x49e2ff,
};

export function palette(over = {}) {
  const mk = (name, color, o = {}) => {
    const m = new THREE.MeshStandardMaterial({ color, roughness: 0.55, metalness: 0.3, ...o });
    m.name = name; return m;
  };
  const c = { ...HEX, ...over };
  return {
    carbon: mk('carbon_shell', c.carbon, { roughness: 0.64, metalness: 0.2 }),
    petrol: mk('petrol_panel', c.petrol, { roughness: 0.48, metalness: 0.34 }),
    gun:    mk('gunmetal_mech', c.gun, { roughness: 0.38, metalness: 0.4 }),
    grey:   mk('faded_grey', c.grey, { roughness: 0.74, metalness: 0.12 }),
    bone:   mk('overspray_bone', c.bone, { roughness: 0.8, metalness: 0.08 }),
    dark:   mk('shadow_black', c.dark, { roughness: 0.85, metalness: 0.06 }),
    acid:   mk('acid_paint', c.acid, { roughness: 0.52, metalness: 0.1 }),
    warn:   mk('warning_orange', c.warn, { roughness: 0.6, metalness: 0.1 }),
    rust:   mk('oxide_patch', c.rust, { roughness: 0.9, metalness: 0.1 }),
    cyanL:  mk('emissive_cyan', 0x0c2c34, { emissive: 0x49e2ff, emissiveIntensity: 1.8, roughness: 0.4, metalness: 0 }),
    acidL:  mk('emissive_acid', 0x1d2609, { emissive: 0xc8ff2e, emissiveIntensity: 1.6, roughness: 0.4, metalness: 0 }),
    warnL:  mk('emissive_warn', 0x2a1004, { emissive: 0xff5a12, emissiveIntensity: 1.5, roughness: 0.4, metalness: 0 }),
    glass:  mk('canopy_smoke', 0x102e37, { roughness: 0.13, metalness: 0.2, transparent: true, opacity: 0.6 }),
  };
}

export function symShape(half) {
  const s = new THREE.Shape();
  s.moveTo(half[0][0], half[0][1]);
  for (let i = 1; i < half.length; i++) s.lineTo(half[i][0], half[i][1]);
  for (let i = half.length - 2; i >= 0; i--) s.lineTo(-half[i][0], half[i][1]);
  s.closePath();
  return s;
}

export function plate(name, mat, half, thick, { y = 0, bevel = 0.025 } = {}) {
  const g = new THREE.ExtrudeGeometry(symShape(half), {
    depth: thick, steps: 1,
    bevelEnabled: bevel > 0, bevelSize: bevel, bevelThickness: bevel, bevelSegments: 1,
  });
  const m = new THREE.Mesh(g, mat);
  m.name = name; m.rotation.x = -Math.PI / 2; m.position.y = y;
  return m;
}

export function blade(name, mat, pts, thick, { bevel = 0.02 } = {}) {
  const s = new THREE.Shape();
  s.moveTo(pts[0][0], pts[0][1]);
  for (let i = 1; i < pts.length; i++) s.lineTo(pts[i][0], pts[i][1]);
  s.closePath();
  const g = new THREE.ExtrudeGeometry(s, {
    depth: thick, steps: 1,
    bevelEnabled: bevel > 0, bevelSize: bevel, bevelThickness: bevel, bevelSegments: 1,
  });
  const m = new THREE.Mesh(g, mat);
  m.name = name; m.rotation.y = Math.PI / 2; m.position.x = -thick / 2;
  const pivot = new THREE.Group(); pivot.name = name + '_pivot'; pivot.add(m);
  return pivot;
}

export function box(name, mat, w, h, d, pos, rot) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
  m.name = name; m.position.set(...pos);
  if (rot) m.rotation.set(...rot);
  return m;
}

export function tube(name, mat, r, len, pos, seg = 12, open = true, rot) {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, len, seg, 1, open), mat);
  m.name = name; m.rotation.x = Math.PI / 2; m.position.set(...pos);
  if (rot) m.rotation.set(Math.PI / 2 + (rot[0] || 0), rot[1] || 0, rot[2] || 0);
  return m;
}

export function taper(name, mat, r1, r2, len, pos, seg = 12, open = true) {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(r1, r2, len, seg, 1, open), mat);
  m.name = name; m.rotation.x = Math.PI / 2; m.position.set(...pos);
  return m;
}

/** Vertical cylinder / cone (Y axis) — tube() and taper() lie along Z. */
export function column(name, mat, r1, r2, len, pos, seg = 12, open = false, rot) {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(r1, r2, len, seg, 1, open), mat);
  m.name = name; m.position.set(...pos);
  if (rot) m.rotation.set(...rot);
  return m;
}

export function disc(name, mat, r, pos, seg = 16) {
  const m = new THREE.Mesh(new THREE.CircleGeometry(r, seg), mat);
  m.name = name; m.position.set(...pos);
  return m;
}

export function mirror(group, fn) { [-1, 1].forEach(s => group.add(fn(s, s < 0 ? 'L' : 'R'))); }

/** Volume-weighted centroid over solid meshes — decal quads, markers and
 *  attachment empties carry no mass. */
export function centreOfMass(g) {
  const acc = new THREE.Vector3(); let mass = 0;
  const bb = new THREE.Box3(), c = new THREE.Vector3(), sz = new THREE.Vector3();
  g.updateMatrixWorld(true);
  g.traverse(o => {
    if (!o.isMesh) return;
    const n = o.material && o.material.name || '';
    if (n.startsWith('decal_') || n.startsWith('marker_')) return;
    bb.setFromObject(o);
    bb.getSize(sz); bb.getCenter(c);
    const m = Math.max(sz.x * sz.y * sz.z, 1e-5);
    acc.addScaledVector(c, m); mass += m;
  });
  return mass ? acc.divideScalar(mass) : new THREE.Vector3();
}

/** mode 'ground': origin under the bbox centre, base at y=0.
 *  mode 'com':    origin at the approximate centre of mass. */
export function finalize(g, { mode = 'ground' } = {}) {
  const b = new THREE.Box3().setFromObject(g);
  const c = b.getCenter(new THREE.Vector3());
  const o = mode === 'none' ? new THREE.Vector3()
    : mode === 'com' ? centreOfMass(g) : new THREE.Vector3(c.x, b.min.y, c.z);
  g.children.forEach(ch => { ch.position.sub(o); });
  g.userData = { ...(g.userData || {}), originOffset: o.toArray(), originMode: mode };
  return g;
}

export function triCount(obj) {
  let t = 0;
  obj.traverse(o => {
    if (!o.isMesh) return;
    const g = o.geometry;
    t += g.index ? g.index.count / 3 : g.attributes.position.count / 3;
  });
  return Math.round(t);
}

/* ── decal atlas ──────────────────────────────────────────────────────
   One transparent 1024² sheet. Cells are px rects; decalTexture() maps
   a cell onto a quad through offset/repeat, exactly as the shipped
   material would.                                                     */

export const CELLS = {
  num_07:      [0, 0, 256, 256],
  emblem_kairo:[256, 0, 256, 256],
  team_mark:   [512, 0, 512, 256],
  warn_plasma: [0, 256, 512, 128],
  warn_nostep: [512, 256, 256, 128],
  warn_lift:   [768, 256, 256, 128],
  stencil_axis:[0, 384, 384, 128],
  stencil_rev: [384, 384, 384, 128],
  grid_stripe: [0, 512, 1024, 128],
  hazard:      [0, 640, 512, 128],
  panel_vent:  [512, 640, 256, 256],
  serial:      [768, 640, 256, 128],
};

export function decalAtlas(size = 1024, { number = '07', team = 'TOTEM SYNDICATE' } = {}) {
  const cv = document.createElement('canvas');
  cv.width = cv.height = size;
  const x = cv.getContext('2d');
  const k = size / 1024;
  const S = (n) => n * k;
  const cell = (c) => CELLS[c].map(S);

  const label = (txt, box, { fill = '#cfcabc', font = 700, size: fs = 34, letter = 4, align = 'center' } = {}) => {
    const [cx, cy, cw, ch] = box;
    x.save();
    x.font = `${font} ${S(fs)}px "JetBrains Mono", monospace`;
    x.fillStyle = fill; x.textBaseline = 'middle'; x.textAlign = align;
    let out = '';
    for (const ch2 of txt) out += ch2 + ' '.repeat(0);
    x.letterSpacing = `${S(letter)}px`;
    x.fillText(out, align === 'center' ? cx + cw / 2 : cx + S(12), cy + ch / 2);
    x.restore();
  };

  // race number — huge, slightly off-centre, hand-cut look
  {
    const [cx, cy, cw, ch] = cell('num_07');
    x.fillStyle = '#c8ff2e';
    x.save(); x.translate(cx + cw / 2, cy + ch / 2); x.rotate(-0.04);
    x.font = `800 ${S(170)}px Saira, sans-serif`;
    x.textAlign = 'center'; x.textBaseline = 'middle';
    x.fillText(number, 0, S(6));
    x.restore();
    x.strokeStyle = 'rgba(14,17,20,.9)'; x.lineWidth = S(6);
    x.strokeRect(cx + S(10), cy + S(10), cw - S(20), ch - S(20));
  }
  // manufacturer emblem — chevron inside a hoop
  {
    const [cx, cy, cw, ch] = cell('emblem_kairo');
    const mx = cx + cw / 2, my = cy + ch / 2;
    x.strokeStyle = '#cfcabc'; x.lineWidth = S(10);
    x.beginPath(); x.arc(mx, my, S(88), 0, Math.PI * 2); x.stroke();
    x.beginPath();
    x.moveTo(mx - S(52), my + S(34)); x.lineTo(mx, my - S(44)); x.lineTo(mx + S(52), my + S(34));
    x.lineWidth = S(20); x.strokeStyle = '#49e2ff'; x.stroke();
    label('KAIRO', [cx, cy + ch - S(46), cw, S(34)], { size: 22, fill: '#cfcabc' });
  }
  // team mark
  {
    const [cx, cy, cw, ch] = cell('team_mark');
    x.fillStyle = '#c8ff2e';
    x.fillRect(cx + S(16), cy + S(96), S(64), S(64));
    x.fillStyle = '#cfcabc';
    x.save();
    x.font = `700 ${S(38)}px Saira, sans-serif`;
    x.textBaseline = 'middle'; x.letterSpacing = `${S(2)}px`;
    x.fillText(team, cx + S(96), cy + S(120));
    x.restore();
    label('KAIRO DYNAMICS · CLASS II ANTIGRAV', [cx + S(84), cy + S(156), cw, S(40)], { size: 13, align: 'left', fill: '#8b969a', letter: 2 });
  }
  // warning labels
  const warn = (c, txt, tone = '#f2641b') => {
    const [cx, cy, cw, ch] = cell(c);
    x.fillStyle = tone; x.fillRect(cx, cy, cw, S(8));
    x.fillRect(cx, cy + ch - S(8), cw, S(8));
    label(txt, [cx, cy, cw, ch], { size: 23, fill: tone, letter: 3 });
  };
  warn('warn_plasma', 'DANGER · PLASMA WASH');
  warn('warn_nostep', 'NO STEP', '#cfcabc');
  warn('warn_lift', 'LIFT HERE', '#49e2ff');
  label('AXIS 4 / TR-88', cell('stencil_axis'), { size: 26, fill: '#8b969a', align: 'left', letter: 3 });
  label('REV 12 · HULL 0714', cell('stencil_rev'), { size: 26, fill: '#8b969a', align: 'left', letter: 3 });
  // spine stripe
  {
    const [cx, cy, cw, ch] = cell('grid_stripe');
    x.fillStyle = '#c8ff2e'; x.fillRect(cx, cy + S(40), cw, S(48));
    x.fillStyle = '#0e1114';
    for (let i = 0; i < 20; i++) x.fillRect(cx + S(i * 52 + 8), cy + S(40), S(10), S(48));
  }
  // hazard chevrons
  {
    const [cx, cy, cw, ch] = cell('hazard');
    x.fillStyle = '#f2641b';
    for (let i = 0; i < 9; i++) {
      x.save(); x.translate(cx + S(i * 58), cy); x.beginPath();
      x.moveTo(S(0), S(128)); x.lineTo(S(34), 0); x.lineTo(S(62), 0); x.lineTo(S(28), S(128));
      x.closePath(); x.fill(); x.restore();
    }
  }
  // vent / louvre panel
  {
    const [cx, cy, cw, ch] = cell('panel_vent');
    x.fillStyle = 'rgba(14,17,20,.82)'; x.fillRect(cx, cy, cw, ch);
    x.fillStyle = 'rgba(162,168,170,.5)';
    for (let i = 0; i < 7; i++) x.fillRect(cx + S(18), cy + S(20 + i * 32), cw - S(36), S(12));
  }
  label('KD-0714-TTM', cell('serial'), { size: 22, fill: '#8b969a', align: 'left', letter: 2 });
  return cv;
}

export function emissiveSheet(size = 512) {
  const cv = document.createElement('canvas');
  cv.width = cv.height = size;
  const x = cv.getContext('2d');
  const k = size / 512;
  x.fillStyle = '#000'; x.fillRect(0, 0, size, size);
  const glow = (px, py, w, h, col) => {
    const g = x.createLinearGradient(px * k, py * k, px * k, (py + h) * k);
    g.addColorStop(0, col); g.addColorStop(.5, '#fff'); g.addColorStop(1, col);
    x.fillStyle = g; x.fillRect(px * k, py * k, w * k, h * k);
  };
  glow(16, 16, 480, 40, '#49e2ff');            // exhaust core ramp
  glow(16, 80, 480, 28, '#c8ff2e');            // spine strip
  glow(16, 132, 224, 24, '#ff5a12');           // port lamp
  glow(272, 132, 224, 24, '#49e2ff');          // starboard lamp
  x.fillStyle = '#0e1114'; x.fillRect(16 * k, 180 * k, 480 * k, 316 * k);
  x.fillStyle = '#49e2ff';
  for (let i = 0; i < 6; i++) x.fillRect((32 + i * 78) * k, 200 * k, 46 * k, 46 * k);
  x.fillStyle = '#c8ff2e';
  for (let i = 0; i < 6; i++) x.fillRect((32 + i * 78) * k, 268 * k, 46 * k, 24 * k);
  x.fillStyle = '#8b969a';
  x.font = `500 ${12 * k}px "JetBrains Mono", monospace`;
  x.fillText('EXHAUST · SPINE · LAMPS · COCKPIT / BEACON CELLS', 20 * k, 340 * k);
  return cv;
}

let _atlasTex = null;
export function decalTexture(cellName, atlasCanvas) {
  if (!_atlasTex) {
    _atlasTex = new THREE.CanvasTexture(atlasCanvas || decalAtlas());
    _atlasTex.colorSpace = THREE.SRGBColorSpace;
    _atlasTex.anisotropy = 1;
  }
  const t = _atlasTex.clone();
  t.needsUpdate = true;
  const [cx, cy, cw, ch] = CELLS[cellName];
  t.offset.set(cx / 1024, 1 - (cy + ch) / 1024);
  t.repeat.set(cw / 1024, ch / 1024);
  return t;
}

/** Flat textured quad lifted off the hull — how the shipped model
 *  carries numbers, emblems and warning labels. */
const _decalMats = new Map();
export function decal(name, cellName, w, h, pos, rot = [0, 0, 0], atlas) {
  let mat = _decalMats.get(cellName);
  if (!mat) {
    mat = new THREE.MeshStandardMaterial({
      map: decalTexture(cellName, atlas), transparent: true, alphaTest: 0.04,
      roughness: 0.62, metalness: 0.08, depthWrite: false,
    });
    mat.name = 'decal_' + cellName;
    _decalMats.set(cellName, mat);
  }
  const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), mat);
  m.name = name; m.position.set(...pos); m.rotation.set(...rot);
  m.castShadow = false;
  return m;
}
