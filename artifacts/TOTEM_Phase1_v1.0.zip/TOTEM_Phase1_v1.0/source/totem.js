import * as THREE from 'three';
import {
  palette, plate, blade, box, tube, taper, disc, mirror, finalize, decal, decalAtlas,
} from './kit-lib.js';

const LIVERY = {
  works:     { over: {}, accent: 'acid', trim: 'petrol', note: 'Works team' },
  privateer: { over: { carbon: 0x2c3138, petrol: 0x6b6f6a }, accent: 'warn', trim: 'bone', note: 'Privateer' },
  nightform: { over: { carbon: 0x14181c, petrol: 0x122b36 }, accent: 'cyan', trim: 'dark', note: 'Night form' },
};

const HULL = [[0, 3.20], [0.24, 2.55], [0.32, 1.10], [0.42, -0.30], [1.42, -1.60], [1.52, -2.20], [1.10, -2.45], [0.92, -2.62], [0, -2.68]];
const KEEL = [[0, 2.85], [0.20, 2.30], [0.27, 1.05], [0.36, -0.30], [1.24, -1.52], [1.34, -2.08], [0.98, -2.32], [0, -2.44]];
const DECK = [[0, 2.62], [0.22, 1.78], [0.29, -0.40], [0.26, -1.92], [0, -1.98]];

/** The production TOTEM.
 *  opts: livery, deflect (control surfaces at full travel), markers
 *  (attachment points visible), decals, atlas (shared canvas) */
export function buildTotem(opts = {}) {
  const { livery = 'works', deflect = false, markers = false, decals = true, atlas, origin = 'ground' } = opts;
  const L = LIVERY[livery] || LIVERY.works;
  const P = palette(L.over);
  const ACC = P[L.accent === 'cyan' ? 'cyanL' : L.accent];
  const TRIM = P[L.trim];
  const d = deflect ? 1 : 0;
  const g = new THREE.Group();
  g.name = 'TOTEM_' + livery;

  /* ── hull ─────────────────────────────────────────────────────── */
  g.add(plate('keel_underfloor', P.dark, KEEL, 0.15, { y: 0.11 }));
  g.add(plate('hull_blade', P.carbon, HULL, 0.40, { y: 0.24, bevel: 0.05 }));
  mirror(g, (s, k) => box('side_skirt_' + k, P.dark, 0.07, 0.16, 2.6, [s * 1.33, 0.20, 1.0], [0, s * 0.05, 0]));
  mirror(g, (s, k) => box('aft_deck_panel_' + k, P.gun, 0.62, 0.05, 0.9, [s * 0.72, 0.655, 1.85], [0, 0, 0]));
  g.add(plate('spine_deck', TRIM, DECK, 0.30, { y: 0.62, bevel: 0.04 }));
  g.add(plate('nose_shroud', P.gun, [[0, 3.30], [0.18, 2.68], [0.24, 2.05], [0, 2.0]], 0.26, { y: 0.34 }));
  g.add(taper('nose_probe', P.gun, 0.05, 0.015, 0.44, [0, 0.46, -3.42], 8, false));
  // shoulder chines: hard chamfer along the aft plan-view
  mirror(g, (s, k) => box('chine_' + k, P.gun, 0.10, 0.09, 1.5, [s * 1.36, 0.30, 1.35], [0, s * 0.10, 0]));
  // avionics blister + intake vents
  g.add(box('avionics_blister', P.gun, 0.44, 0.16, 0.9, [0, 0.95, -0.55]));
  mirror(g, (s, k) => {
    const v = new THREE.Group(); v.name = 'deck_vent_' + k;
    v.add(box('deck_vent_well_' + k, P.dark, 0.17, 0.06, 0.64, [s * 0.20, 0.935, 0.35]));
    for (let i = 0; i < 5; i++) v.add(box('louvre_' + k + '_' + i, P.gun, 0.16, 0.02, 0.05, [s * 0.20, 0.955, 0.13 + i * 0.115], [0.5, 0, 0]));
    return v;
  });
  mirror(g, (s, k) => box('radiator_' + k, P.dark, 0.34, 0.20, 0.5, [s * 0.52, 0.44, 0.9], [0, 0, s * 0.08]));
  mirror(g, (s, k) => box('grab_handle_' + k, P.gun, 0.06, 0.10, 0.30, [s * 0.46, 0.72, -0.9]));

  /* ── cockpit ──────────────────────────────────────────────────── */
  const hinge = new THREE.Group();
  hinge.name = 'canopy_pivot';
  hinge.position.set(0, 0.84, -0.72);
  hinge.rotation.x = -0.62 * d;
  hinge.userData = { mover: true, axis: 'x', rangeDeg: [-36, 0], driver: 'canopy' };
  const canopy = new THREE.Mesh(new THREE.SphereGeometry(0.34, 10, 6), P.glass);
  canopy.name = 'canopy_glass_shell';
  canopy.scale.set(0.66, 0.62, 2.15);
  canopy.position.set(0, 0.06, -0.62);
  hinge.add(canopy);
  hinge.add(box('canopy_frame', P.carbon, 0.50, 0.07, 1.42, [0, -0.04, -0.62]));
  g.add(hinge);
  g.add(box('cockpit_tub', P.dark, 0.46, 0.22, 1.30, [0, 0.72, -1.30]));
  g.add(box('seat_back', P.gun, 0.30, 0.26, 0.10, [0, 0.86, -0.76]));
  g.add(box('seat_pan', P.dark, 0.30, 0.06, 0.30, [0, 0.74, -0.94]));
  g.add(box('dash_shroud', P.dark, 0.36, 0.12, 0.22, [0, 0.80, -1.72], [-0.35, 0, 0]));
  g.add(box('dash_screen', P.cyanL, 0.24, 0.02, 0.14, [0, 0.855, -1.70], [-0.35, 0, 0]));
  g.add(tube('control_column', P.gun, 0.022, 0.24, [0, 0.86, -1.42], 6, false, [1.2, 0, 0]));
  g.add(box('blade_antenna', P.gun, 0.03, 0.20, 0.10, [0.16, 1.03, -0.35], [0.15, 0, 0]));

  /* ── forward outriggers + steering fins ───────────────────────── */
  mirror(g, (s, k) => {
    const o = new THREE.Group(); o.name = 'outrigger_' + k;
    o.add(tube('boom_' + k, P.gun, 0.115, 2.5, [s * 1.38, 0.44, -1.72], 12, false));
    o.add(box('boom_tip_' + k, P.dark, 0.19, 0.15, 0.42, [s * 1.38, 0.44, -3.02]));
    o.add(box('boom_lamp_' + k, s < 0 ? P.warnL : P.cyanL, 0.14, 0.10, 0.08, [s * 1.38, 0.44, -3.25]));
    o.add(box('boom_root_fairing_' + k, P.carbon, 0.26, 0.20, 0.62, [s * 1.38, 0.44, -0.62]));
    o.add(box('boom_strut_' + k, P.carbon, 1.15, 0.13, 0.30, [s * 0.86, 0.44, -0.78], [0, s * 0.30, 0]));
    // cable bundle along the strut
    [-0.05, 0.05].forEach((o2, i) =>
      o.add(tube('cable_' + k + '_' + i, P.dark, 0.028, 1.1, [s * 0.86, 0.36 + o2 * 0.6, -0.78], 6, false, [0, s * 0.30, 0])));
    const fin = blade('steering_fin_' + k, ACC, [[0, 0], [0.66, 0.04], [0.46, 0.42], [-0.02, 0.36]], 0.05);
    fin.userData = { mover: true, axis: 'y', rangeDeg: [-20, 20], driver: 'steer' };
    fin.position.set(s * 1.38, 0.52, -2.62);
    fin.rotation.z = -s * 0.30;
    fin.rotation.y = s * 0.34 * d;
    o.add(fin);
    return o;
  });

  /* ── propulsion pair ──────────────────────────────────────────── */
  mirror(g, (s, k) => {
    const n = new THREE.Group(); n.name = 'engine_' + k;
    const cz = 1.48, r = 0.31, len = 1.95;
    n.add(tube('engine_barrel_' + k, P.carbon, r, len, [s * 0.45, 0.74, cz], 28));
    n.add(tube('engine_liner_' + k, P.dark, r * 0.84, len * 0.98, [s * 0.45, 0.74, cz], 28));
    const boltRing = new THREE.Mesh(new THREE.TorusGeometry(r * 1.01, 0.028, 6, 28), P.gun);
    boltRing.name = 'engine_bolt_ring_' + k; boltRing.position.set(s * 0.45, 0.74, cz - 0.28);
    n.add(boltRing);
    for (let i = 0; i < 9; i++) {
      const a = (i / 9) * Math.PI * 2;
      const bl = box('fan_blade_' + k + '_' + i, P.gun, 0.05, r * 0.66, 0.04,
        [s * 0.45 + Math.cos(a) * r * 0.42, 0.74 + Math.sin(a) * r * 0.42, cz - len / 2 + 0.16], [0, 0.4, a]);
      n.add(bl);
    }
    n.add(taper('engine_hub_' + k, P.dark, 0.06, 0.11, 0.26, [s * 0.45, 0.74, cz - len / 2 + 0.2], 10, false));
    const lip = new THREE.Mesh(new THREE.TorusGeometry(r * 0.95, r * 0.13, 10, 26), P.gun);
    lip.name = 'intake_lip_' + k; lip.position.set(s * 0.45, 0.74, cz - len / 2);
    n.add(lip);
    n.add(taper('exhaust_bell_' + k, P.gun, r * 1.1, r * 0.88, len * 0.24, [s * 0.45, 0.74, cz + len / 2 - 0.02], 28));
    n.add(disc('exhaust_core_' + k, P.cyanL, r * 0.8, [s * 0.45, 0.74, cz + len / 2 + 0.05], 24));
    n.add(box('engine_spine_rail_' + k, P.gun, 0.07, 0.07, len * 0.8, [s * 0.45, 0.74 + r, cz]));
    // movable nozzle flaps
    [-1, 1].forEach((sy, i) => {
      const f = blade('engine_flap_' + k + '_' + i, P.gun,
        [[0, -r * 0.95], [0.40, -r * 1.06], [0.40, r * 0.06], [0, r * 0.06]], 0.05);
      f.userData = { mover: true, axis: 'x', rangeDeg: [9, 29], driver: 'throttle' };
      f.position.set(s * 0.45, 0.74 + sy * (r * 0.02), cz + len / 2 - 0.42);
      f.rotation.x = sy * (0.16 + 0.34 * d);
      f.rotation.z = sy > 0 ? 0 : Math.PI;
      n.add(f);
    });
    return n;
  });

  /* ── signature: exposed stabiliser ring (local pivot at hoop centre) ── */
  const RY = 0.76, RZ = 2.62, RR = 1.04;
  const ring = new THREE.Group();
  ring.name = 'stabiliser_ring_pivot';
  ring.position.set(0, RY, RZ);
  ring.userData = { mover: true, axis: 'z', rangeDeg: [-12, 12], driver: 'roll' };
  const hoop = new THREE.Mesh(new THREE.TorusGeometry(RR, 0.088, 12, 48), P.grey);
  hoop.name = 'ring_hoop';
  ring.add(hoop);
  const inner = new THREE.Mesh(new THREE.TorusGeometry(RR - 0.16, 0.032, 8, 40), P.gun);
  inner.name = 'ring_inner_race'; inner.position.z = -0.02;
  ring.add(inner);
  [0, 1, 2, 3, 4, 5].forEach(i => {
    const a = Math.PI / 6 + i * Math.PI / 3;
    for (let j = 0; j < 2; j++) {
      const a2 = a + (j ? 1 : -1) * Math.PI / 6;
      ring.add(box('ring_boss_min_' + i + '_' + j, P.gun, 0.10, 0.10, 0.10, [Math.cos(a2) * RR, Math.sin(a2) * RR, 0]));
    }
    const spar = box('ring_spar_' + i, P.carbon, 0.09, 0.09, 1.02,
      [Math.cos(a) * RR * 0.55, Math.sin(a) * RR * 0.55, -0.42]);
    spar.lookAt(new THREE.Vector3(Math.cos(a) * RR, Math.sin(a) * RR, 0));
    ring.add(spar);
    ring.add(box('ring_boss_' + i, P.gun, 0.17, 0.17, 0.12, [Math.cos(a) * RR, Math.sin(a) * RR, 0]));
  });
  ring.add(box('ring_yoke', P.gun, 0.9, 0.14, 0.34, [0, -0.62, -0.5]));
  mirror(ring, (s2, k) => box('ring_beacon_' + k, s2 < 0 ? P.acidL : P.cyanL, 0.15, 0.15, 0.10, [s2 * RR, 0, 0.02]));
  ring.add(box('ring_patch_paint', P.rust, 0.30, 0.12, 0.13, [RR * 0.71, RR * 0.71, 0]));
  g.add(ring);

  /* ── control surfaces ─────────────────────────────────────────── */
  const dorsal = blade('dorsal_fin', P.carbon, [[-0.22, 0], [1.10, 0.06], [0.74, 0.94], [-0.14, 0.62]], 0.08);
  dorsal.position.set(0, 0.92, 0.75);
  g.add(dorsal);
  g.add(box('dorsal_fin_stripe', ACC, 0.10, 0.44, 0.30, [0, 1.28, 1.18], [0.2, 0, 0]));
  mirror(g, (s, k) => {
    const b = blade('airbrake_' + k, P.warn, [[0, 0], [0.62, 0], [0.62, 0.40], [0, 0.40]], 0.05);
    b.userData = { mover: true, axis: 'x', rangeDeg: [0, 60], driver: 'brake' };
    b.position.set(s * 0.95, 0.63, 1.05);
    b.rotation.x = Math.PI / 2 - (0.10 + 1.05 * d);
    b.rotation.z = s * 0.05;
    return b;
  });
  mirror(g, (s, k) => {
    const e = blade('elevon_' + k, P.carbon, [[0, 0], [0.42, 0.02], [0.42, 0.46], [0, 0.52]], 0.05);
    e.userData = { mover: true, axis: 'y', rangeDeg: [-15, 15], driver: 'pitch_roll' };
    e.position.set(s * 1.12, 0.40, 2.42);
    e.rotation.x = Math.PI / 2;
    e.rotation.z = s * 0.02;
    e.rotation.y = -0.26 * d;
    return e;
  });

  /* ── landing supports ─────────────────────────────────────────── */
  const skid = (name, pos, len) => {
    const s2 = new THREE.Group(); s2.name = name + '_pivot';
    s2.position.set(pos[0], pos[1] + 0.24, pos[2]);
    s2.add(box(name + '_leg', P.gun, 0.07, 0.24, 0.09, [0, -0.12, 0]));
    s2.add(box(name + '_pad', P.dark, 0.15, 0.07, len, [0, -0.205, 0]));
    return s2;
  };
  const skids = new THREE.Group();
  skids.name = 'skids_pivot';
  skids.userData = { mover: true, translate: 'y', rangeM: [-0.22, 0], driver: 'gear' };
  mirror(skids, (s, k) => skid('skid_' + k, [s * 0.95, 0, 1.55], 0.9));
  skids.add(skid('skid_nose', [0, 0, -2.05], 0.62));
  g.add(skids);

  /* ── decals ───────────────────────────────────────────────────── */
  if (decals) {
    const A = atlas;
    const D = new THREE.Group(); D.name = 'decals';
    const up = -Math.PI / 2;
    const TOP = 0.648, SIDE = 0.44;
    // deck (narrow spine, y 0.925)
    D.add(decal('decal_number_deck', 'num_07', 0.44, 0.44, [0, 0.926, 0.62], [up, 0, 0], A));
    D.add(decal('decal_spine_stripe', 'grid_stripe', 0.19, 3.4, [0, 0.927, -0.42], [up, 0, Math.PI / 2], A));
    // aft shoulders (the wide plan-view)
    D.add(decal('decal_team_mark', 'team_mark', 1.36, 0.33, [0, TOP, 2.34], [up, 0, 0], A));
    mirror(D, (s2, k) => decal('decal_warn_plasma_' + k, 'warn_plasma', 0.86, 0.19, [s2 * 1.0, TOP, 1.95], [up, 0, 0], A));
    mirror(D, (s2, k) => decal('decal_nostep_' + k, 'warn_nostep', 0.40, 0.15, [s2 * 1.04, TOP, 1.28], [up, 0, 0], A));
    mirror(D, (s2, k) => decal('decal_hazard_' + k, 'hazard', 0.66, 0.17, [s2 * 1.28, TOP, 2.06], [up, 0, 0], A));
    D.add(decal('decal_lift_here', 'warn_lift', 0.46, 0.16, [0.60, TOP, 2.40], [up, 0, 0], A));
    D.add(decal('decal_stencil_axis', 'stencil_axis', 0.58, 0.17, [-0.60, TOP, 2.40], [up, 0, 0], A));
    D.add(decal('decal_stencil_rev', 'stencil_rev', 0.58, 0.17, [-1.02, TOP, 1.62], [up, 0, 0], A));
    // hull sides
    mirror(D, (s2, k) => decal('decal_number_hull_' + k, 'num_07', 0.33, 0.33, [s2 * 0.435, SIDE, 0.20], [0, s2 * Math.PI / 2, 0], A));
    mirror(D, (s2, k) => decal('decal_emblem_' + k, 'emblem_kairo', 0.29, 0.29, [s2 * 0.345, SIDE, -1.10], [0, s2 * Math.PI / 2, 0], A));
    mirror(D, (s2, k) => decal('decal_vent_' + k, 'panel_vent', 0.31, 0.31, [s2 * 0.99, SIDE, 1.00], [0, s2 * Math.PI / 2, 0], A));
    // transom
    D.add(decal('decal_serial', 'serial', 0.44, 0.15, [0.34, 0.42, 2.71], [0, 0, 0], A));
    g.add(D);
  }

  /* ── attachment points (exported as empties) ──────────────────── */
  const ATT = [
    ['FX_engine_left', [-0.45, 0.74, 2.52], 'thrust'],
    ['FX_engine_right', [0.45, 0.74, 2.52], 'thrust'],
    ['FX_boost_center', [0, 0.76, 2.62], 'thrust'],
    ['FX_trail_wing_left', [-1.52, 0.44, 2.20], 'trail'],
    ['FX_trail_wing_right', [1.52, 0.44, 2.20], 'trail'],
    ['FX_trail_boom_left', [-1.38, 0.44, -3.25], 'trail'],
    ['FX_trail_boom_right', [1.38, 0.44, -3.25], 'trail'],
    ['FX_dust_front_left', [-0.28, 0.10, -1.70], 'hover'],
    ['FX_dust_front_right', [0.28, 0.10, -1.70], 'hover'],
    ['FX_dust_rear_left', [-1.20, 0.10, 1.80], 'hover'],
    ['FX_dust_rear_right', [1.20, 0.10, 1.80], 'hover'],
    ['FX_impact_nose', [0, 0.44, -3.30], 'impact'],
    ['FX_impact_left', [-1.53, 0.44, 2.05], 'impact'],
    ['FX_impact_right', [1.53, 0.44, 2.05], 'impact'],
    ['FX_spine_flare', [0, 0.95, -0.35], 'light'],
    ['LIGHT_nav_left', [-1.38, 0.44, -3.25], 'light'],
    ['LIGHT_nav_right', [1.38, 0.44, -3.25], 'light'],
    ['LIGHT_ring_left', [-1.04, 0.76, 2.64], 'light'],
    ['LIGHT_ring_right', [1.04, 0.76, 2.64], 'light'],
    ['CAMERA_chase_target', [0, 1.55, 4.60], 'camera'],
  ];
  const MC = { thrust: 0x49e2ff, trail: 0xc8ff2e, light: 0xf2641b, impact: 0xff2e4c, hover: 0xa2a8aa, camera: 0xffffff };
  const anchors = new THREE.Group(); anchors.name = 'attachments';
  ATT.forEach(([name, pos, type]) => {
    const o = new THREE.Object3D(); o.name = name; o.position.set(...pos);
    if (markers) {
      const mat = new THREE.MeshStandardMaterial({
        color: MC[type], emissive: MC[type], emissiveIntensity: 1.4, roughness: 0.4,
      });
      mat.name = 'marker_' + type;
      const m = new THREE.Mesh(new THREE.OctahedronGeometry(type === 'camera' ? 0.14 : 0.085), mat);
      m.name = name + '_marker';
      o.add(m);
      if (type === 'camera') {
        const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 1.5, 6), mat);
        stem.name = name + '_stem'; stem.rotation.x = Math.PI / 2; stem.position.z = -0.75;
        o.add(stem);
      }
    }
    anchors.add(o);
  });
  g.add(anchors);

  return finalize(g, { mode: origin });
}

export { LIVERY };
export const sharedAtlas = () => decalAtlas();
