/* Minimal STORE-method ZIP writer — no dependency, deterministic output.
   files: [{ name, data: ArrayBuffer | Uint8Array | string }] → Blob        */

const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[i] = c >>> 0;
  }
  return t;
})();

function crc32(bytes) {
  let c = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) c = CRC_TABLE[(c ^ bytes[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

const enc = new TextEncoder();

function toBytes(d) {
  if (typeof d === 'string') return enc.encode(d);
  if (d instanceof Uint8Array) return d;
  return new Uint8Array(d);
}

/** Fixed DOS timestamp so repeat builds of the same inputs are byte-identical. */
const DOS_TIME = 0x6000;                 // 12:00:00
const DOS_DATE = ((2026 - 1980) << 9) | (8 << 5) | 23;   // 2026-08-23

export function makeZip(files) {
  const entries = files.map(f => {
    const name = enc.encode(f.name);
    const data = toBytes(f.data);
    return { name, data, crc: crc32(data), offset: 0 };
  });

  let size = 0;
  for (const e of entries) size += 30 + e.name.length + e.data.length;
  const cdStart = size;
  for (const e of entries) size += 46 + e.name.length;
  const total = size + 22;

  const out = new Uint8Array(total);
  const dv = new DataView(out.buffer);
  let p = 0;
  const u16 = (v) => { dv.setUint16(p, v, true); p += 2; };
  const u32 = (v) => { dv.setUint32(p, v, true); p += 4; };
  const raw = (b) => { out.set(b, p); p += b.length; };

  for (const e of entries) {
    e.offset = p;
    u32(0x04034b50); u16(20); u16(0x0800); u16(0);            // sig, version, UTF-8 flag, store
    u16(DOS_TIME); u16(DOS_DATE);
    u32(e.crc); u32(e.data.length); u32(e.data.length);
    u16(e.name.length); u16(0);
    raw(e.name); raw(e.data);
  }
  for (const e of entries) {
    u32(0x02014b50); u16(20); u16(20); u16(0x0800); u16(0);
    u16(DOS_TIME); u16(DOS_DATE);
    u32(e.crc); u32(e.data.length); u32(e.data.length);
    u16(e.name.length); u16(0); u16(0);
    u16(0); u16(0); u32(0);
    u32(e.offset);
    raw(e.name);
  }
  u32(0x06054b50); u16(0); u16(0);
  u16(entries.length); u16(entries.length);
  u32(total - 22 - cdStart); u32(cdStart); u16(0);

  return new Blob([out], { type: 'application/zip' });
}
