import * as THREE from 'three';
import { palette, plate, blade, box, tube, taper, column, disc, mirror, finalize, decal } from './kit-lib.js';

const P = palette();
const mk = (name, color, o = {}) => {
  const m = new THREE.MeshStandardMaterial({ color, roughness: 0.6, metalness: 0.2, ...o });
  m.name = name; return m;
};
const FOL = mk('foliage_deep', 0x24402c, { roughness: 0.86, metalness: 0.04 });
const FOL2 = mk('foliage_pale', 0x4a6b39, { roughness: 0.82, metalness: 0.04 });
const CONC = mk('cast_concrete', 0x5a5f5c, { roughness: 0.92, metalness: 0.03 });

/* ── 01 start-grid marker ─────────────────────────────────────────── */
export function gridMarker(n = '07') {
  const g = new THREE.Group(); g.name = 'PROP_grid_marker';
  g.add(plate('grid_pad', CONC, [[0, 0.9], [0.85, 0.55], [0.85, -0.55], [0, -0.9]], 0.06, { y: 0 }));
  g.add(box('grid_chevron', P.acid, 1.24, 0.025, 0.22, [0, 0.078, 0.30]));
  g.add(box('grid_chevron_b', P.acid, 1.24, 0.025, 0.22, [0, 0.078, -0.04]));
  mirror(g, (s, k) => box('grid_post_' + k, P.gun, 0.10, 0.62, 0.10, [s * 0.72, 0.31, -0.62]));
  g.add(box('grid_plate', P.carbon, 1.30, 0.42, 0.07, [0, 0.62, -0.62]));
  g.add(box('grid_plate_light', P.acidL, 1.16, 0.05, 0.03, [0, 0.43, -0.578]));
  g.add(decal('grid_number', 'num_07', 0.30, 0.30, [0, 0.67, -0.575]));
  g.add(box('grid_kerb', P.warn, 1.7, 0.09, 0.09, [0, 0.045, 0.86]));
  return finalize(g);
}

/* ── 02 repair / charging unit ────────────────────────────────────── */
export function repairUnit() {
  const g = new THREE.Group(); g.name = 'PROP_repair_unit';
  g.add(box('unit_skid_base', P.dark, 1.50, 0.14, 1.05, [0, 0.07, 0]));
  g.add(box('unit_cabinet', P.petrol, 1.34, 1.42, 0.92, [0, 0.85, 0]));
  g.add(box('unit_roof', P.gun, 1.44, 0.10, 1.02, [0, 1.60, 0], [0.06, 0, 0]));
  g.add(box('unit_door_panel', P.carbon, 0.86, 1.00, 0.04, [0, 0.86, 0.47]));
  g.add(box('unit_readout', P.cyanL, 0.42, 0.16, 0.03, [0, 1.32, 0.48]));
  g.add(box('unit_hazard_band', P.warn, 1.36, 0.14, 0.94, [0, 0.24, 0]));
  g.add(box('unit_vent', P.dark, 0.5, 0.36, 0.05, [0.40, 0.60, -0.47]));
  // charging arms
  mirror(g, (s, k) => {
    const a = new THREE.Group(); a.name = 'unit_arm_' + k;
    a.add(column('arm_boom_' + k, P.gun, 0.055, 0.055, 0.95, [s * 0.62, 1.26, 0.34], 8, false, [0.95, 0, 0]));
    a.add(box('arm_clamp_' + k, P.warn, 0.16, 0.12, 0.20, [s * 0.62, 0.95, 0.66]));
    a.add(column('arm_hose_' + k, P.dark, 0.035, 0.035, 0.68, [s * 0.62, 0.58, 0.66], 6, false));
    return a;
  });
  // cable spool
  const spool = new THREE.Mesh(new THREE.CylinderGeometry(0.26, 0.26, 0.20, 14), P.dark);
  spool.name = 'unit_spool'; spool.rotation.z = Math.PI / 2; spool.position.set(-0.74, 0.60, -0.24);
  g.add(spool);
  g.add(box('unit_lamp', P.warnL, 0.14, 0.10, 0.14, [0.56, 1.70, 0]));
  return finalize(g);
}

/* ── 03 track beacon ──────────────────────────────────────────────── */
export function trackBeacon() {
  const g = new THREE.Group(); g.name = 'PROP_track_beacon';
  g.add(plate('beacon_foot', CONC, [[0, 0.52], [0.45, 0.26], [0.45, -0.26], [0, -0.52]], 0.10, { y: 0 }));
  [0, 1, 2].forEach(i => {
    const a = (i / 3) * Math.PI * 2;
    g.add(box('beacon_leg_' + i, P.gun, 0.07, 0.72, 0.07,
      [Math.cos(a) * 0.30, 0.42, Math.sin(a) * 0.30], [Math.sin(a) * -0.3, 0, Math.cos(a) * 0.3]));
  });
  g.add(column('beacon_column', P.carbon, 0.13, 0.10, 1.95, [0, 1.62, 0], 12, false));
  g.add(box('beacon_collar', P.gun, 0.26, 0.10, 0.26, [0, 2.58, 0]));
  const head = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.34, 14, 1, true), P.dark);
  head.name = 'beacon_head'; head.position.y = 2.82; g.add(head);
  const lens = new THREE.Mesh(new THREE.CylinderGeometry(0.245, 0.245, 0.16, 14, 1, true), P.cyanL);
  lens.name = 'beacon_lens'; lens.position.y = 2.82; g.add(lens);
  g.add(box('beacon_cap', P.gun, 0.52, 0.07, 0.52, [0, 3.02, 0]));
  g.add(column('beacon_whip', P.gun, 0.014, 0.014, 0.75, [0.16, 3.42, 0], 6, false, [0, 0, -0.10]));
  g.add(box('beacon_box', P.petrol, 0.24, 0.30, 0.18, [0, 1.05, 0.18]));
  g.add(box('beacon_box_light', P.acidL, 0.12, 0.04, 0.03, [0, 1.14, 0.28]));
  return finalize(g);
}

/* ── 04 warning light ─────────────────────────────────────────────── */
export function warningLight() {
  const g = new THREE.Group(); g.name = 'PROP_warning_light';
  g.add(box('warn_base', P.dark, 0.34, 0.09, 0.34, [0, 0.045, 0]));
  g.add(column('warn_post', P.gun, 0.045, 0.045, 1.28, [0, 0.73, 0], 8, false));
  g.add(box('warn_bracket', P.gun, 0.20, 0.07, 0.14, [0, 1.36, 0]));
  const dome = new THREE.Mesh(new THREE.SphereGeometry(0.16, 10, 6, 0, Math.PI * 2, 0, Math.PI / 2), P.warnL);
  dome.name = 'warn_dome'; dome.position.y = 1.42; g.add(dome);
  [0, 1, 2, 3].forEach(i => {
    const a = (i / 4) * Math.PI * 2 + 0.4;
    g.add(box('warn_cage_' + i, P.gun, 0.02, 0.24, 0.02, [Math.cos(a) * 0.15, 1.50, Math.sin(a) * 0.15]));
  });
  g.add(box('warn_cage_top', P.gun, 0.26, 0.03, 0.26, [0, 1.62, 0]));
  g.add(box('warn_stripe', P.warn, 0.06, 0.44, 0.06, [0, 0.55, 0]));
  return finalize(g);
}

/* ── 05 navigation pylon ──────────────────────────────────────────── */
export function navPylon() {
  const g = new THREE.Group(); g.name = 'PROP_nav_pylon';
  g.add(plate('pylon_base', CONC, [[0, 0.80], [0.68, 0.48], [0.68, -0.48], [0, -0.80]], 0.22, { y: 0 }));
  g.add(box('pylon_shaft', P.carbon, 0.52, 3.60, 0.34, [0, 2.00, 0]));
  g.add(box('pylon_shaft_edge', P.gun, 0.07, 3.60, 0.36, [0.27, 2.00, 0]));
  // hollow head frame
  g.add(box('pylon_frame_top', P.gun, 1.30, 0.16, 0.28, [0, 4.62, 0]));
  g.add(box('pylon_frame_bot', P.gun, 1.30, 0.16, 0.28, [0, 3.86, 0]));
  mirror(g, (s, k) => box('pylon_frame_side_' + k, P.gun, 0.16, 0.92, 0.28, [s * 0.57, 4.24, 0]));
  g.add(box('pylon_gate_light', P.acidL, 1.02, 0.10, 0.10, [0, 4.50, 0.10]));
  g.add(box('pylon_gate_light_b', P.cyanL, 1.02, 0.10, 0.10, [0, 3.98, 0.10]));
  const chev = blade('pylon_chevron', P.acid, [[0, 0], [0.5, 0.42], [0.5, 0.62], [-0.02, 0.20]], 0.06);
  chev.position.set(0.20, 2.30, 0.18);
  g.add(chev);
  g.add(box('pylon_stencil_band', P.warn, 0.54, 0.13, 0.36, [0, 0.42, 0]));
  g.add(tube('pylon_conduit', P.dark, 0.05, 3.2, [-0.24, 1.9, 0.14], 6, false, [Math.PI / 2, 0, 0]));
  return finalize(g);
}

/* ── 06 antenna / sensor tower ────────────────────────────────────── */
export function antennaTower() {
  const g = new THREE.Group(); g.name = 'PROP_antenna_tower';
  g.add(plate('tower_pad', CONC, [[0, 0.95], [0.82, 0.58], [0.82, -0.58], [0, -0.95]], 0.16, { y: 0 }));
  const H = 5.4;
  [[-1, -1], [-1, 1], [1, -1], [1, 1]].forEach(([sx, sz], i) => {
    const leg = box('tower_leg_' + i, P.gun, 0.09, H, 0.09, [sx * 0.42, H / 2 + 0.14, sz * 0.42]);
    leg.rotation.set(sz * 0.045, 0, -sx * 0.045);
    g.add(leg);
  });
  for (let i = 0; i < 6; i++) {
    const y = 0.55 + i * 0.92;
    g.add(box('tower_ring_' + i, P.gun, 0.90 - i * 0.03, 0.05, 0.90 - i * 0.03, [0, y, 0]));
    g.add(box('tower_brace_a_' + i, P.gun, 1.22, 0.04, 0.04, [0, y + 0.46, 0.40], [0, 0, 0.7]));
    g.add(box('tower_brace_b_' + i, P.gun, 1.22, 0.04, 0.04, [0, y + 0.46, -0.40], [0, 0, -0.7]));
  }
  g.add(box('tower_head', P.carbon, 0.60, 0.44, 0.60, [0, 5.72, 0]));
  const dish = new THREE.Mesh(new THREE.SphereGeometry(0.46, 12, 6, 0, Math.PI * 2, 0, Math.PI / 2.4), P.grey);
  dish.name = 'tower_dish'; dish.rotation.set(1.25, 0, 0); dish.position.set(0, 5.72, 0.42);
  g.add(dish);
  g.add(tube('tower_dish_stem', P.gun, 0.03, 0.34, [0, 5.72, 0.28], 6, false, [Math.PI / 2, 0, 0]));
  g.add(box('tower_lamp', P.warnL, 0.13, 0.13, 0.13, [0, 6.02, 0]));
  [0.2, -0.2].forEach((x, i) => g.add(column('tower_whip_' + i, P.gun, 0.012, 0.012, 1.3, [x, 6.6, 0], 6, false, [0, 0, i ? 0.06 : -0.06])));
  g.add(box('tower_cabinet', P.petrol, 0.52, 0.62, 0.40, [0.62, 0.45, 0.20]));
  g.add(box('tower_cabinet_light', P.cyanL, 0.20, 0.05, 0.03, [0.62, 0.66, 0.41]));
  return finalize(g);
}

/* ── 07 modular cable bundle ──────────────────────────────────────── */
export function cableBundle() {
  const g = new THREE.Group(); g.name = 'PROP_cable_bundle';
  const span = 3.0;
  mirror(g, (s, k) => {
    const b = new THREE.Group(); b.name = 'cable_bracket_' + k;
    b.add(box('bracket_plate_' + k, P.gun, 0.44, 0.36, 0.16, [0, 0.62, s * span / 2]));
    b.add(box('bracket_foot_' + k, P.dark, 0.52, 0.10, 0.28, [0, 0.05, s * span / 2]));
    b.add(tube('bracket_post_' + k, P.gun, 0.05, 0.60, [0, 0.34, s * span / 2], 8, false, [Math.PI / 2, 0, 0]));
    return b;
  });
  // catenary runs
  const runs = [[-0.14, 0.66, 0x0e1114], [-0.05, 0.70, 0x0e1114], [0.04, 0.68, 0x1f2a2e], [0.13, 0.62, 0x0e1114], [0.19, 0.58, 0x2c3138]];
  runs.forEach(([x, y0, col], i) => {
    const mat = mk('cable_sheath_' + (i % 2), col, { roughness: 0.9, metalness: 0.05 });
    const pts = [];
    for (let t = 0; t <= 8; t++) {
      const u = t / 8, z = -span / 2 + u * span;
      pts.push(new THREE.Vector3(x, y0 - Math.sin(u * Math.PI) * 0.30, z));
    }
    const c = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 12, 0.028, 6, false), mat);
    c.name = 'cable_run_' + i;
    g.add(c);
  });
  g.add(box('cable_junction', P.petrol, 0.36, 0.34, 0.26, [0.05, 0.30, 0.35]));
  g.add(box('cable_junction_light', P.acidL, 0.14, 0.04, 0.03, [0.05, 0.40, 0.49]));
  g.add(box('cable_tag', P.warn, 0.16, 0.10, 0.02, [-0.05, 0.44, -0.60]));
  return finalize(g);
}

/* ── 08–10 low-poly jungle plants ─────────────────────────────────── */
function leaf(name, mat, len, wid, curl) {
  const s = new THREE.Shape();
  s.moveTo(0, 0); s.lineTo(wid * 0.5, len * 0.28); s.lineTo(wid * 0.34, len * 0.78);
  s.lineTo(0, len); s.lineTo(-wid * 0.34, len * 0.78); s.lineTo(-wid * 0.5, len * 0.28);
  s.closePath();
  const m = new THREE.Mesh(new THREE.ExtrudeGeometry(s, { depth: 0.014, bevelEnabled: false }), mat);
  m.name = name; m.rotation.x = curl;
  return m;
}

export function plantFrond() {
  const g = new THREE.Group(); g.name = 'PROP_plant_frond';
  g.add(column('frond_stalk', FOL, 0.07, 0.03, 0.55, [0, 0.28, 0], 8, false));
  for (let i = 0; i < 7; i++) {
    const a = (i / 7) * Math.PI * 2;
    const p = new THREE.Group(); p.name = 'frond_leaf_pivot_' + i;
    p.add(leaf('frond_leaf_' + i, i % 2 ? FOL : FOL2, 1.35, 0.42, -0.55));
    p.position.set(0, 0.52, 0);
    p.rotation.y = a; p.rotation.x = -0.9 - (i % 3) * 0.12;
    g.add(p);
  }
  return finalize(g);
}

export function plantReeds() {
  const g = new THREE.Group(); g.name = 'PROP_plant_reeds';
  g.add(box('reed_clump_base', FOL, 0.34, 0.10, 0.34, [0, 0.05, 0]));
  for (let i = 0; i < 11; i++) {
    const a = (i / 11) * Math.PI * 2, r = 0.06 + (i % 3) * 0.05;
    const h = 1.5 + (i % 4) * 0.32;
    const st = column('reed_' + i, i % 2 ? FOL : FOL2, 0.022, 0.006, h,
      [Math.cos(a) * r, h / 2 + 0.05, Math.sin(a) * r], 5, false,
      [Math.sin(a) * 0.22, 0, -Math.cos(a) * 0.22]);
    g.add(st);
  }
  return finalize(g);
}

export function plantBroadleaf() {
  const g = new THREE.Group(); g.name = 'PROP_plant_broadleaf';
  g.add(column('broad_stem', FOL, 0.05, 0.03, 0.30, [0, 0.15, 0], 6, false));
  for (let i = 0; i < 4; i++) {
    const p = new THREE.Group(); p.name = 'broad_leaf_pivot_' + i;
    p.add(leaf('broad_leaf_' + i, i % 2 ? FOL2 : FOL, 0.95, 0.72, -0.35));
    p.position.set(0, 0.26, 0);
    p.rotation.y = (i / 4) * Math.PI * 2 + 0.4;
    p.rotation.x = -1.16 - (i % 2) * 0.14;
    g.add(p);
  }
  return finalize(g);
}

export const KIT = [
  ['grid_marker', 'Start-grid marker', gridMarker, '1.7 × 0.9 m', 'One per grid slot. Concrete pad, acid chevrons, lit number plate facing the driver. The kerb bar is the only orange on the grid, so the start line reads as a single warm stripe from the air.'],
  ['repair_unit', 'Repair / charging unit', repairUnit, '1.5 × 1.6 m', 'Pit-lane and roadside. Two clamp arms drop onto the hull spine; hose runs to the keel. Cabinet is petrol, hazard band is at knee height where it gets scuffed.'],
  ['track_beacon', 'Track beacon', trackBeacon, '3.5 m tall', 'Sector markers and gate pairs. The cyan lens band is the world\'s primary navigation cue — always cyan, never acid, so team colour and track information never compete.'],
  ['warning_light', 'Warning light', warningLight, '1.7 m tall', 'Hazard, pit exit, debris. Caged orange dome on a striped post. Small enough to litter a corner without reading as scenery.'],
  ['nav_pylon', 'Navigation pylon', navPylon, '4.9 m tall', 'Gate and split markers. The hollow head frames the racing line; acid above, cyan below tells the player which way through. Reads as a shape at 200 m.'],
  ['antenna_tower', 'Antenna / sensor tower', antennaTower, '7.9 m tall', 'Skyline furniture. Four canted legs, six brace rings, dish and whips. Silhouette only — no detail below 0.04 m, so it survives fog and distance.'],
  ['cable_bundle', 'Modular cable bundle', cableBundle, '3.0 m span', 'Repeats end to end along walls and through canopy. Five sheaths in three darks, one junction box, one tag. The unit that makes the world feel wired.'],
  ['plant_frond', 'Frond palm', plantFrond, '1.6 m', 'Seven leaves off one stalk. Two greens alternating, hard-edged, no alpha cutouts — silhouette does the work.'],
  ['plant_reeds', 'Reed clump', plantReeds, '2.4 m', 'Eleven tapered stalks. Fills gaps between industrial props and softens hard edges at track side.'],
  ['plant_broadleaf', 'Broadleaf', plantBroadleaf, '1.1 m', 'Four wide blades, ground cover. Cheapest plant in the set — use it in mass.'],
];

/** All ten props laid out on a grid for one shared stage / one GLB. */
export function kitLineup() {
  const g = new THREE.Group(); g.name = 'FUTURISMA_asset_kit';
  const order = ['grid_marker', 'repair_unit', 'track_beacon', 'warning_light', 'nav_pylon', 'antenna_tower', 'cable_bundle', 'plant_frond', 'plant_reeds', 'plant_broadleaf'];
  const cols = 5, gap = 3.4;
  order.forEach((id, i) => {
    const entry = KIT.find(k => k[0] === id);
    const o = entry[2]();
    o.position.set((i % cols - (cols - 1) / 2) * gap, 0, (Math.floor(i / cols) - 0.5) * gap * 1.15);
    g.add(o);
  });
  return g;
}
